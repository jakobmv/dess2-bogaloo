"""
20 Newsgroups + SBERT embeddings.

Loads 20NG, embeds every document with a sentence-transformer,
caches the embeddings to disk so re-runs are cheap. Returns a simple
dict of numpy arrays and class names.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
from sklearn.datasets import fetch_20newsgroups
from sklearn.model_selection import train_test_split

from config import CFG, CACHE_DIR, DataConfig
from utils import cache_pickle


@dataclass
class Dataset20NG:
    """
    Container for the processed dataset.

    Each split contains:
        X_emb : (N, embedding_dim) float32   SBERT embeddings
        y     : (N,)              int64     class indices
    """
    X_train: np.ndarray
    y_train: np.ndarray
    X_val: np.ndarray
    y_val: np.ndarray
    X_test: np.ndarray
    y_test: np.ndarray

    class_names: list[str]
    in_dist_classes: list[int]   # class indices kept for main experiments
    ood_classes: list[int]       # class indices held out for OOD test

    # OOD split — only populated if ood_classes is non-empty
    X_ood: Optional[np.ndarray] = None
    y_ood: Optional[np.ndarray] = None

    @property
    def embedding_dim(self) -> int:
        return self.X_train.shape[1]

    @property
    def n_classes(self) -> int:
        return len(self.in_dist_classes)


def _embed_texts(texts: list[str], model_name: str) -> np.ndarray:
    """Encode texts with sentence-transformers. Batched, uses GPU if available."""
    # Imported lazily — sentence-transformers is heavy and we want cache hits
    # to avoid importing it at all.
    from sentence_transformers import SentenceTransformer
    import torch

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = SentenceTransformer(model_name, device=device)
    embeddings = model.encode(
        texts,
        batch_size=64,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,   # keep raw embeddings — DESS samples geometry
    )
    return embeddings.astype(np.float32)


def _build_dataset(cfg: DataConfig) -> Dataset20NG:
    """Heavy build: fetch 20NG + embed + split. Only runs on cache miss."""
    print("[data] fetching 20 newsgroups...")
    bundle = fetch_20newsgroups(
        subset="all",
        remove=cfg.remove_metadata,
        shuffle=True,
        random_state=42,
    )
    texts: list[str] = bundle.data
    labels: np.ndarray = np.asarray(bundle.target, dtype=np.int64)
    class_names: list[str] = list(bundle.target_names)

    # filter out empty docs (happens after header/footer/quote removal)
    keep = [i for i, t in enumerate(texts) if len(t.strip()) > 20]
    texts = [texts[i] for i in keep]
    labels = labels[keep]
    print(f"[data] {len(texts)} documents after filtering")

    print(f"[data] embedding with {cfg.sbert_model}...")
    X = _embed_texts(texts, cfg.sbert_model)

    # split OOD classes off first
    ood_class_ids = [class_names.index(c) for c in cfg.ood_classes if c in class_names]
    in_dist_class_ids = [i for i in range(len(class_names)) if i not in ood_class_ids]

    ood_mask = np.isin(labels, ood_class_ids)
    X_ood, y_ood = X[ood_mask], labels[ood_mask]
    X_id, y_id = X[~ood_mask], labels[~ood_mask]

    # remap in-distribution labels to dense 0..K-1 so downstream code is cleaner
    id_remap = {old: new for new, old in enumerate(in_dist_class_ids)}
    y_id_remapped = np.array([id_remap[y] for y in y_id], dtype=np.int64)

    # train/val/test on in-distribution data, stratified
    test_frac = cfg.test_frac
    val_frac_of_remain = cfg.val_frac / (cfg.train_frac + cfg.val_frac)

    X_tv, X_test, y_tv, y_test = train_test_split(
        X_id, y_id_remapped,
        test_size=test_frac,
        random_state=42,
        stratify=y_id_remapped,
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_tv, y_tv,
        test_size=val_frac_of_remain,
        random_state=42,
        stratify=y_tv,
    )

    print(f"[data] splits — train={len(X_train)} val={len(X_val)} "
          f"test={len(X_test)} ood={len(X_ood)}")
    print(f"[data] in-distribution classes: {len(in_dist_class_ids)}")
    print(f"[data] OOD classes: {[class_names[i] for i in ood_class_ids]}")

    return Dataset20NG(
        X_train=X_train, y_train=y_train,
        X_val=X_val, y_val=y_val,
        X_test=X_test, y_test=y_test,
        class_names=class_names,
        in_dist_classes=in_dist_class_ids,
        ood_classes=ood_class_ids,
        X_ood=X_ood if len(X_ood) else None,
        y_ood=y_ood if len(y_ood) else None,
    )


def load_dataset(cfg: Optional[DataConfig] = None, force_rebuild: bool = False) -> Dataset20NG:
    """Public entry point. Cached on disk keyed by SBERT model name."""
    cfg = cfg or CFG.data
    cache_path = CACHE_DIR / f"20ng_{cfg.sbert_model.replace('/', '_')}.pkl"
    if force_rebuild and cache_path.exists():
        cache_path.unlink()
    return cache_pickle(cache_path, lambda: _build_dataset(cfg))
