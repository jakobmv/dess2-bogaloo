"""
Training loops.

The multi-target training setup for 20NG:
    - Input x = one-hot encoding of class c
    - Target Y = a random subset of T training embeddings from class c

This directly matches Section 3.2.3 of the paper: one input, multiple targets
drawn from the class-conditional distribution of embeddings.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from config import TrainConfig, ModelConfig
from data import Dataset20NG
from model import DESSModel, RegressionBaseline, SoftmaxBaseline
from losses import multi_target_loss, single_target_loss, regression_loss


# --------------------------------------------------------------------------
# Dataset adapters
# --------------------------------------------------------------------------
class MultiTargetDataset(Dataset):
    """
    Yields (x_onehot, Y) where Y is a tensor of T embeddings from class c.
    Iterating over classes rather than documents — one step = one class.
    We sample with replacement if a class has fewer than T embeddings.
    """

    def __init__(
        self,
        X: np.ndarray,
        y: np.ndarray,
        n_classes: int,
        targets_per_input: int,
        steps_per_epoch: Optional[int] = None,
    ):
        self.X = X
        self.y = y
        self.n_classes = n_classes
        self.T = targets_per_input
        # group indices by class once, sample from them each __getitem__
        self.class_indices = [np.where(y == c)[0] for c in range(n_classes)]
        self.steps_per_epoch = steps_per_epoch or (len(X) // targets_per_input)

    def __len__(self):
        return self.steps_per_epoch

    def __getitem__(self, idx):
        c = idx % self.n_classes
        pool = self.class_indices[c]
        chosen = np.random.choice(pool, size=self.T, replace=len(pool) < self.T)
        Y = self.X[chosen]                                    # (T, D)
        x_onehot = np.zeros(self.n_classes, dtype=np.float32)
        x_onehot[c] = 1.0
        return x_onehot, Y.astype(np.float32)


class PointDataset(Dataset):
    """Plain (x_onehot, y_single_embedding) — for single-target & regression baseline."""

    def __init__(self, X: np.ndarray, y: np.ndarray, n_classes: int):
        self.X = X
        self.y = y
        self.n_classes = n_classes

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        x_onehot = np.zeros(self.n_classes, dtype=np.float32)
        x_onehot[self.y[idx]] = 1.0
        return x_onehot, self.X[idx].astype(np.float32), int(self.y[idx])


# --------------------------------------------------------------------------
# Training loops
# --------------------------------------------------------------------------
@dataclass
class TrainResult:
    model: torch.nn.Module
    history: list[dict]        # per-epoch log of loss components


def train_dess(
    dataset: Dataset20NG,
    cfg: TrainConfig,
    model_cfg: ModelConfig,
    device: torch.device,
    multi_target: bool = True,
    verbose: bool = True,
) -> TrainResult:
    """Train a DESSModel on 20NG with the multi-target loss."""
    n_classes = dataset.n_classes
    D = dataset.embedding_dim

    model = DESSModel(in_dim=n_classes, embedding_dim=D, cfg=model_cfg).to(device)
    opt = torch.optim.Adam(
        model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay
    )

    if multi_target:
        ds = MultiTargetDataset(
            dataset.X_train, dataset.y_train,
            n_classes=n_classes,
            targets_per_input=cfg.targets_per_input,
        )
        loader = DataLoader(ds, batch_size=cfg.batch_size, shuffle=True, num_workers=0)
    else:
        ds = PointDataset(dataset.X_train, dataset.y_train, n_classes)
        loader = DataLoader(ds, batch_size=cfg.batch_size, shuffle=True, num_workers=0)

    history = []
    for epoch in range(cfg.epochs):
        model.train()
        agg = {"loss_total": 0.0, "loss_mu": 0.0, "loss_sigma": 0.0}
        n_batches = 0

        for batch in loader:
            if multi_target:
                x, Y = batch
                x, Y = x.to(device), Y.to(device)
                mu_hat, spread_hat = model(x)
                loss, info = multi_target_loss(
                    mu_hat, spread_hat, Y, beta=cfg.beta, alpha=cfg.alpha
                )
            else:
                x, y, _ = batch
                x, y = x.to(device), y.to(device)
                mu_hat, spread_hat = model(x)
                loss, info = single_target_loss(
                    mu_hat, spread_hat, y, beta=cfg.beta
                )

            opt.zero_grad()
            loss.backward()
            opt.step()

            for k in agg:
                agg[k] += info.get(k, 0.0)
            n_batches += 1

        for k in agg:
            agg[k] /= max(n_batches, 1)
        agg["epoch"] = epoch
        history.append(agg)

        if verbose and (epoch % 10 == 0 or epoch == cfg.epochs - 1):
            print(f"  epoch {epoch:3d}  "
                  f"L={agg['loss_total']:.4f}  "
                  f"L_mu={agg['loss_mu']:.4f}  "
                  f"L_sigma={agg['loss_sigma']:.4f}")

    return TrainResult(model=model, history=history)


def train_regression_baseline(
    dataset: Dataset20NG,
    cfg: TrainConfig,
    model_cfg: ModelConfig,
    device: torch.device,
    verbose: bool = True,
) -> TrainResult:
    """DESS minus the sigma head — the direct ablation from Experiment 1."""
    n_classes = dataset.n_classes
    D = dataset.embedding_dim

    model = RegressionBaseline(in_dim=n_classes, embedding_dim=D, cfg=model_cfg).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)

    ds = PointDataset(dataset.X_train, dataset.y_train, n_classes)
    loader = DataLoader(ds, batch_size=cfg.batch_size, shuffle=True, num_workers=0)

    history = []
    for epoch in range(cfg.epochs):
        model.train()
        total = 0.0
        n_batches = 0
        for x, y, _ in loader:
            x, y = x.to(device), y.to(device)
            mu_hat = model(x)
            loss, info = regression_loss(mu_hat, y)
            opt.zero_grad()
            loss.backward()
            opt.step()
            total += info["loss_total"]
            n_batches += 1
        history.append({"epoch": epoch, "loss_total": total / max(n_batches, 1)})
        if verbose and (epoch % 10 == 0 or epoch == cfg.epochs - 1):
            print(f"  epoch {epoch:3d}  L={history[-1]['loss_total']:.4f}")

    return TrainResult(model=model, history=history)


def train_softmax_baseline(
    dataset: Dataset20NG,
    cfg: TrainConfig,
    model_cfg: ModelConfig,
    device: torch.device,
    verbose: bool = True,
) -> TrainResult:
    """
    Standard softmax classifier — upper bound for Experiment 1.
    Input is SBERT embedding (not one-hot label) since we're doing true classification.
    """
    n_classes = dataset.n_classes
    D = dataset.embedding_dim

    model = SoftmaxBaseline(in_dim=D, n_classes=n_classes, cfg=model_cfg).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)

    X_tr = torch.from_numpy(dataset.X_train).float()
    y_tr = torch.from_numpy(dataset.y_train).long()
    n = len(X_tr)

    history = []
    for epoch in range(cfg.epochs):
        model.train()
        perm = torch.randperm(n)
        total = 0.0
        n_batches = 0
        for i in range(0, n, cfg.batch_size):
            idx = perm[i : i + cfg.batch_size]
            x, y = X_tr[idx].to(device), y_tr[idx].to(device)
            logits = model(x)
            loss = F.cross_entropy(logits, y)
            opt.zero_grad()
            loss.backward()
            opt.step()
            total += loss.item()
            n_batches += 1
        history.append({"epoch": epoch, "loss_total": total / max(n_batches, 1)})
        if verbose and (epoch % 10 == 0 or epoch == cfg.epochs - 1):
            print(f"  epoch {epoch:3d}  L={history[-1]['loss_total']:.4f}")

    return TrainResult(model=model, history=history)
