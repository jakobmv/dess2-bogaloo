"""
Plotting helpers for the follow-up analyses.

Keeps the same style as plots.py — swap it out in one place if you want
paper-final aesthetics.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import matplotlib.pyplot as plt

from plots import _save   # reuse the existing save-as-png+pdf helper


# --------------------------------------------------------------------------
# A — sample-distance histogram
# --------------------------------------------------------------------------
def plot_sample_distance_histogram(
    results_by_beta: dict[float, dict],
    name: str = "expA_sample_distance",
):
    """
    For each β, show the distribution of 'distance from sample to own μ' as
    a histogram, with vertical lines for the expected distance (‖σ‖, from
    concentration of measure) and the inter-class minimum distance.
    """
    betas = sorted(results_by_beta.keys())
    n = len(betas)
    fig, axes = plt.subplots(1, n, figsize=(3.2 * n, 3.8), sharey=True)
    if n == 1:
        axes = [axes]

    # shared x-axis range across panels
    all_d = np.concatenate([r["dist_to_own"].flatten() for r in results_by_beta.values()])
    xmax = float(np.quantile(all_d, 0.99))

    for ax, beta in zip(axes, betas):
        r = results_by_beta[beta]
        d = r["dist_to_own"].flatten()
        ax.hist(d, bins=40, range=(0, xmax), color="#5577aa", alpha=0.75)
        # expected distance under concentration-of-measure (mean ‖σ‖ across classes)
        exp_mean = float(np.mean(r["expected_dist"]))
        ax.axvline(exp_mean, ls="--", color="k", lw=1.2, label=f"mean ||σ||={exp_mean:.2f}")
        # distance to the nearest other class's μ — if sample distance exceeds this,
        # the sample is misclassified
        ax.axvline(r["inter_class_min"], ls=":", color="red", lw=1.2,
                   label=f"min inter-class={r['inter_class_min']:.2f}")
        ax.set_title(f"β = {beta}   (misplaced {100*r['fraction_misplaced']:.0f}%)")
        ax.set_xlabel("‖sample − μ‖₂")
        ax.legend(fontsize=7)

    axes[0].set_ylabel("count")
    plt.suptitle(
        f"Sample displacement from own μ (d = {list(results_by_beta.values())[0]['d']})",
        y=1.02,
    )
    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# B — fine-grained β sweep
# --------------------------------------------------------------------------
def plot_fine_beta_sweep(
    beta_results: list[dict],
    point_estimate_accuracy: Optional[float] = None,
    name: str = "expB_fine_beta",
):
    """
    Like Experiment 3's plot but showing a wider/finer β range. Adds a
    horizontal line for the point-estimate accuracy reference.
    """
    betas = [r["beta"] for r in beta_results]
    accs = [r["accuracy"] for r in beta_results]
    spreads = [r["mean_spread_norm"] for r in beta_results]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    ax = axes[0]
    ax.plot(betas, accs, "o-", color="#5577aa", label="sampled accuracy")
    if point_estimate_accuracy is not None:
        ax.axhline(point_estimate_accuracy, ls="--", color="k",
                   lw=1, label=f"point estimate ({point_estimate_accuracy:.2f})")
    ax.set_xscale("log")
    ax.set_xlabel("β (log scale)")
    ax.set_ylabel("Accuracy")
    ax.set_title("Fine-grained β sweep")
    ax.legend()

    ax = axes[1]
    ax.plot(betas, spreads, "o-", color="#aa5577")
    ax.set_xscale("log")
    ax.set_xlabel("β (log scale)")
    ax.set_ylabel("Mean ‖σ‖")
    ax.set_title("Learned spread magnitude")

    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# C — top-k accuracy
# --------------------------------------------------------------------------
def plot_topk_accuracy(
    topk_by_beta: dict[float, dict],
    top_ks: tuple = (1, 3, 5, 10),
    name: str = "expC_topk",
):
    """
    One line per K in top_ks, showing how top-K accuracy varies with β.
    If higher K stays high while K=1 collapses, DESS is dispersing into
    semantic neighbors rather than wrong classes.
    """
    betas = sorted(topk_by_beta.keys())
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    # left: sampled top-K
    ax = axes[0]
    for K in top_ks:
        vals = [topk_by_beta[b][f"top_{K}"] for b in betas]
        ax.plot(betas, vals, "o-", label=f"top-{K}")
    ax.set_xlabel("β")
    ax.set_ylabel("Top-K accuracy (sampled)")
    ax.set_title("Sampled top-K accuracy vs β")
    ax.legend()

    # right: point-estimate top-K for reference (constant across β, but plot as band)
    ax = axes[1]
    point_k = {K: topk_by_beta[betas[0]][f"point_top_{K}"] for K in top_ks}
    ax.bar([str(K) for K in top_ks], [point_k[K] for K in top_ks], color="#aa5577")
    ax.set_xlabel("K")
    ax.set_ylabel("Top-K accuracy (point estimate)")
    ax.set_title("Point estimate top-K (reference)")
    ax.set_ylim(0, 1)

    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# E — calibration plot
# --------------------------------------------------------------------------
def plot_calibration(result: dict, name: str = "expE_calibration"):
    """
    Calibration: predicted σ bucketed on x-axis, empirical coverage on y-axis.
    Well-calibrated Gaussian → points lie on the 0.683 horizontal line.
    """
    fig, ax = plt.subplots()
    ax.plot(result["bin_sigma"], result["bin_coverage"], "o-",
            color="#5577aa", label="empirical coverage")
    ax.axhline(result["expected_coverage"], ls="--", color="k", lw=1.2,
               label=f"expected ({result['distribution_name']}, {result['expected_coverage']:.2f})")
    ax.set_xlabel("Predicted σ (bin mean)")
    ax.set_ylabel("Empirical fraction within ±σ")
    ax.set_ylim(0, 1.05)
    ax.set_title(
        f"σ calibration — overall coverage {result['overall_coverage']:.2f} "
        f"vs expected {result['expected_coverage']:.2f}"
    )
    ax.legend()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# F — per-dimension σ structure
# --------------------------------------------------------------------------
def plot_per_dim_sigma(result: dict, name: str = "expF_per_dim_sigma"):
    """
    Three-panel figure:
        (left)   heatmap of σ per (class, dim) — sorted for visual clarity
        (middle) per-dimension mean σ across classes
        (right)  per-dimension *std* of σ across classes (= structure score)
    """
    sigma = result["sigma_matrix"]                 # (n_classes, D)
    per_dim_mean = result["sigma_per_dim_mean"]
    per_dim_std = result["sigma_per_dim_std"]

    # sort dimensions by mean σ for a more readable heatmap
    order = np.argsort(per_dim_mean)
    sigma_sorted = sigma[:, order]

    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    ax = axes[0]
    im = ax.imshow(sigma_sorted, aspect="auto", cmap="viridis")
    ax.set_xlabel("Dimension (sorted by mean σ)")
    ax.set_ylabel("Class index")
    ax.set_title("σ per (class, dim)")
    plt.colorbar(im, ax=ax, label="σ")

    ax = axes[1]
    ax.plot(np.arange(len(per_dim_mean)), np.sort(per_dim_mean), color="#5577aa")
    ax.set_xlabel("Dimension (sorted)")
    ax.set_ylabel("Mean σ across classes")
    ax.set_title("Per-dim mean σ")

    ax = axes[2]
    # scatter: per-dim mean vs per-dim std of σ
    ax.scatter(per_dim_mean, per_dim_std, s=8, alpha=0.5, color="#aa5577")
    ax.set_xlabel("Mean σ (across classes)")
    ax.set_ylabel("Std of σ (across classes)")
    ax.set_title("Per-dim structure")

    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)
