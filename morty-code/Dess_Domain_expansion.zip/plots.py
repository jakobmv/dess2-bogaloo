"""
Plotting helpers.

Keeping all plots in one module means styling stays consistent across
figures and swapping in paper-ready fonts/sizes is a one-line change.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import matplotlib.pyplot as plt

from config import FIGURES_DIR


# Paper-friendly default style. Swap to seaborn-whitegrid if you prefer.
plt.rcParams.update({
    "figure.figsize": (6.0, 4.0),
    "font.size": 11,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "lines.linewidth": 1.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
})


def _save(fig, name: str, out_dir: Optional[Path] = None):
    out_dir = Path(out_dir or FIGURES_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(out_dir / f"{name}.{ext}", dpi=200, bbox_inches="tight")
    print(f"  [figure] saved {out_dir / name}.(png|pdf)")


# --------------------------------------------------------------------------
# Training curves
# --------------------------------------------------------------------------
def plot_training_history(history: list[dict], name: str = "training_history"):
    fig, ax = plt.subplots()
    epochs = [h["epoch"] for h in history]
    for key in ("loss_total", "loss_mu", "loss_sigma"):
        if key in history[0]:
            ax.plot(epochs, [h[key] for h in history], label=key)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.set_title("DESS training")
    ax.legend()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# Experiment 2a — predicted vs empirical sigma
# --------------------------------------------------------------------------
def plot_sigma_vs_empirical(result: dict, name: str = "exp2a_sigma_scatter"):
    pred = result["predicted_sigma"].flatten()
    emp = result["empirical_sigma"].flatten()
    rho = result["spearman_rho"]

    fig, ax = plt.subplots()
    ax.scatter(emp, pred, s=4, alpha=0.4)
    lo = min(emp.min(), pred.min())
    hi = max(emp.max(), pred.max())
    ax.plot([lo, hi], [lo, hi], "k--", lw=1, label="y = x")
    ax.set_xlabel("Empirical per-dim std")
    ax.set_ylabel("Predicted σ")
    ax.set_title(f"Predicted σ vs empirical std (Spearman ρ = {rho:.2f})")
    ax.legend()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# Experiment 2b — sigma by overlap group
# --------------------------------------------------------------------------
def plot_sigma_by_group(result: dict, name: str = "exp2b_sigma_groups"):
    groups = result["group_sigmas"]
    iso = result["isolated_sigmas"]

    labels = list(groups.keys()) + ["isolated"]
    data = [groups[k] for k in groups] + [iso]

    fig, ax = plt.subplots(figsize=(7, 4))
    positions = np.arange(len(labels))
    ax.boxplot(data, positions=positions, widths=0.6, patch_artist=True,
               boxprops=dict(facecolor="#88aadd", alpha=0.6))
    for i, vals in enumerate(data):
        ax.scatter([positions[i]] * len(vals), vals, color="black", s=20, zorder=3)
    ax.set_xticks(positions)
    ax.set_xticklabels(labels, rotation=20)
    ax.set_ylabel("||σ||")
    ax.set_title("Predicted σ magnitude by class overlap group")
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# Experiment 2c — OOD ROC
# --------------------------------------------------------------------------
def plot_ood_roc(result: dict, name: str = "exp2c_ood_roc"):
    from sklearn.metrics import roc_curve

    if "skipped" in result:
        print(f"  [plot] skipping OOD plot: {result['skipped']}")
        return

    id_s = result["id_scores"]
    ood_s = result["ood_scores"]
    y_true = np.concatenate([np.zeros(len(id_s)), np.ones(len(ood_s))])
    y_score = np.concatenate([id_s, ood_s])
    fpr, tpr, _ = roc_curve(y_true, y_score)

    fig, ax = plt.subplots()
    ax.plot(fpr, tpr, label=f"AUROC = {result['auroc']:.3f}")
    ax.plot([0, 1], [0, 1], "k--", lw=1)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("OOD detection via ||σ||")
    ax.legend()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# Experiment 3 — beta sweep pareto
# --------------------------------------------------------------------------
def plot_beta_sweep(
    beta_results: list[dict],
    name: str = "exp3_beta_sweep",
):
    """beta_results: list of dicts with keys {beta, accuracy, mean_ild, mean_spread_norm}"""
    betas = [r["beta"] for r in beta_results]
    accs = [r["accuracy"] for r in beta_results]
    ilds = [r["mean_ild"] for r in beta_results]
    spreads = [r["mean_spread_norm"] for r in beta_results]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    ax = axes[0]
    sc = ax.scatter(ilds, accs, c=betas, cmap="viridis", s=80, zorder=3)
    for b, x, y in zip(betas, ilds, accs):
        ax.annotate(f"β={b}", (x, y), xytext=(4, 4),
                    textcoords="offset points", fontsize=8)
    ax.set_xlabel("Intra-list diversity")
    ax.set_ylabel("Accuracy")
    ax.set_title("Accuracy vs diversity Pareto frontier")
    plt.colorbar(sc, ax=ax, label="β")

    ax = axes[1]
    ax.plot(betas, spreads, "o-")
    ax.set_xlabel("β")
    ax.set_ylabel("Mean ||σ||")
    ax.set_title("Learned spread magnitude vs β")

    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# Experiment 4 — distribution comparison
# --------------------------------------------------------------------------
def plot_distribution_comparison(
    dist_results: dict[str, dict],
    name: str = "exp4_distributions",
):
    """dist_results: {distribution_name: {accuracy, mean_ild, ...}, ...}"""
    names = list(dist_results.keys())
    accs = [dist_results[n]["accuracy"] for n in names]
    ilds = [dist_results[n]["mean_ild"] for n in names]

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    axes[0].bar(names, accs, color="#88aadd")
    axes[0].set_ylabel("Accuracy")
    axes[0].set_title("Accuracy by inference distribution")
    axes[0].set_ylim(0, 1)

    axes[1].bar(names, ilds, color="#dd8888")
    axes[1].set_ylabel("Intra-list diversity")
    axes[1].set_title("Diversity by inference distribution")

    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)
