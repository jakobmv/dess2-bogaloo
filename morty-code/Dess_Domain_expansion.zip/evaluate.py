"""
Evaluation utilities — one function per experiment's headline metric.

Each function returns a plain dict of metrics so the notebook can
collect results, save them to JSON, and hand them to the plotting module.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score, roc_auc_score
from scipy.stats import spearmanr

from data import Dataset20NG
from distributions import Distribution, get_distribution


# --------------------------------------------------------------------------
# shared helper: predict mu and spread for every class in one pass
# --------------------------------------------------------------------------
@torch.no_grad()
def predict_class_params(
    model: torch.nn.Module,
    n_classes: int,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray]:
    """Return (mu, spread) arrays of shape (n_classes, D)."""
    model.eval()
    x = torch.eye(n_classes, device=device)
    mu, spread = model(x)
    return mu.cpu().numpy(), spread.cpu().numpy()


@torch.no_grad()
def predict_mu_only(
    model: torch.nn.Module,
    n_classes: int,
    device: torch.device,
) -> np.ndarray:
    """For RegressionBaseline — returns (n_classes, D)."""
    model.eval()
    x = torch.eye(n_classes, device=device)
    mu = model(x)
    return mu.cpu().numpy()


# --------------------------------------------------------------------------
# EXPERIMENT 1: does DESS work on real data at all?
# --------------------------------------------------------------------------
def classify_by_nearest_centroid(
    X: np.ndarray,                 # (N, D) embeddings to classify
    class_centers: np.ndarray,     # (n_classes, D)
) -> np.ndarray:
    """Argmax over negative Euclidean distance to each class center."""
    # use squared L2 — ties in argmax are unchanged by sqrt
    diff = X[:, None, :] - class_centers[None, :, :]
    d2 = (diff ** 2).sum(axis=-1)
    return d2.argmin(axis=1)


def eval_dess_classification(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    distribution: Distribution = None,
    n_samples: int = 1,
) -> dict:
    """
    Classify test embeddings by nearest learned mu.
    If n_samples > 1, sample from the predicted distribution and
    majority-vote the nearest class.
    """
    mu, spread = predict_class_params(model, dataset.n_classes, device)
    X_test, y_test = dataset.X_test, dataset.y_test

    if n_samples <= 1:
        preds = classify_by_nearest_centroid(X_test, mu)
    else:
        # Per-class sampled "centroids" — sample n_samples class params then
        # for each test embedding, find nearest sample across all class*sample
        dist = distribution or get_distribution("gaussian")
        mu_t = torch.from_numpy(mu).to(device)
        spread_t = torch.from_numpy(spread).to(device)
        # samples shape: (n_samples, n_classes, D)
        samples = dist.sample_many(mu_t, spread_t, k=n_samples)
        samples_np = samples.cpu().numpy().reshape(-1, mu.shape[1])  # (n_samples*n_classes, D)
        labels_rep = np.tile(np.arange(dataset.n_classes), n_samples)
        nearest_sample_idx = classify_by_nearest_centroid(X_test, samples_np)
        preds = labels_rep[nearest_sample_idx]

    acc = (preds == y_test).mean()
    macro_f1 = f1_score(y_test, preds, average="macro")
    return {"accuracy": float(acc), "macro_f1": float(macro_f1)}


def eval_regression_classification(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
) -> dict:
    mu = predict_mu_only(model, dataset.n_classes, device)
    preds = classify_by_nearest_centroid(dataset.X_test, mu)
    return {
        "accuracy": float((preds == dataset.y_test).mean()),
        "macro_f1": float(f1_score(dataset.y_test, preds, average="macro")),
    }


def eval_softmax_classification(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
) -> dict:
    model.eval()
    with torch.no_grad():
        x = torch.from_numpy(dataset.X_test).float().to(device)
        logits = model(x)
        preds = logits.argmax(dim=-1).cpu().numpy()
    return {
        "accuracy": float((preds == dataset.y_test).mean()),
        "macro_f1": float(f1_score(dataset.y_test, preds, average="macro")),
    }


def eval_centroid_floor(dataset: Dataset20NG) -> dict:
    """Nearest-centroid trivial baseline, uses train-set centroids."""
    centers = np.stack([
        dataset.X_train[dataset.y_train == c].mean(axis=0)
        for c in range(dataset.n_classes)
    ])
    preds = classify_by_nearest_centroid(dataset.X_test, centers)
    return {
        "accuracy": float((preds == dataset.y_test).mean()),
        "macro_f1": float(f1_score(dataset.y_test, preds, average="macro")),
    }


# --------------------------------------------------------------------------
# EXPERIMENT 2: is sigma meaningful?
# --------------------------------------------------------------------------
def eval_sigma_vs_empirical(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
) -> dict:
    """
    2a — correlate predicted per-(class, dimension) sigma against the
    empirical standard deviation of training embeddings for that class.
    """
    _, spread = predict_class_params(model, dataset.n_classes, device)

    empirical = np.stack([
        dataset.X_train[dataset.y_train == c].std(axis=0)
        for c in range(dataset.n_classes)
    ])

    # flatten across all (class, dim) pairs
    x = spread.flatten()
    y = empirical.flatten()
    rho, pval = spearmanr(x, y)

    # also per-class correlation — how well does sigma recover the dim-wise variance
    per_class_rho = []
    for c in range(dataset.n_classes):
        r, _ = spearmanr(spread[c], empirical[c])
        per_class_rho.append(float(r) if not np.isnan(r) else 0.0)

    return {
        "spearman_rho": float(rho),
        "spearman_pvalue": float(pval),
        "per_class_rho_mean": float(np.mean(per_class_rho)),
        "per_class_rho_std": float(np.std(per_class_rho)),
        "predicted_sigma": spread,       # for plotting
        "empirical_sigma": empirical,    # for plotting
    }


def eval_sigma_by_overlap_group(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
) -> dict:
    """
    2b — known overlap pairs in 20NG should produce higher sigma than isolated classes.

    Assumes `dataset.class_names` and `dataset.in_dist_classes` are set up such that
    index `i` in predicted spread corresponds to class name
    `dataset.class_names[dataset.in_dist_classes[i]]`.
    """
    _, spread = predict_class_params(model, dataset.n_classes, device)
    sigma_norm = np.linalg.norm(spread, axis=1)   # one scalar per class

    # Hand-picked overlap groups — these are the classic 20NG clusters
    overlap_groups = {
        "computer":   ["comp.graphics", "comp.os.ms-windows.misc",
                       "comp.sys.ibm.pc.hardware", "comp.sys.mac.hardware",
                       "comp.windows.x"],
        "religion":   ["soc.religion.christian", "talk.religion.misc", "alt.atheism"],
        "politics":   ["talk.politics.guns", "talk.politics.mideast", "talk.politics.misc"],
        "sport":      ["rec.sport.baseball", "rec.sport.hockey"],
        "autos":      ["rec.autos", "rec.motorcycles"],
    }

    # map our dense in-distribution indices back to class names
    name_by_local = {
        local: dataset.class_names[orig]
        for local, orig in enumerate(dataset.in_dist_classes)
    }
    name_to_local = {v: k for k, v in name_by_local.items()}

    group_sigmas: dict[str, list[float]] = {}
    for group_name, members in overlap_groups.items():
        vals = [sigma_norm[name_to_local[m]] for m in members if m in name_to_local]
        if vals:
            group_sigmas[group_name] = vals

    isolated = [name_by_local[c] for c in range(dataset.n_classes)
                if not any(name_by_local[c] in members for members in overlap_groups.values())]
    isolated_sigmas = [sigma_norm[name_to_local[n]] for n in isolated]

    return {
        "sigma_norm_per_class": sigma_norm,
        "class_names": [name_by_local[c] for c in range(dataset.n_classes)],
        "group_sigmas": group_sigmas,
        "isolated_sigmas": isolated_sigmas,
        "isolated_classes": isolated,
    }


def eval_sigma_ood_detection(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
) -> dict:
    """
    2c — can we detect OOD inputs via predicted sigma magnitude?

    For each embedding (test ID or OOD), find the nearest class centroid
    under DESS's predicted mu. Use the spread norm of that class as the
    uncertainty score. Compute AUROC for the binary task ID vs OOD.

    NB: OOD embeddings aren't associated with any trained class, so this
    measures "does the model refuse confident predictions for unfamiliar
    inputs" — the epistemic uncertainty story.
    """
    if dataset.X_ood is None:
        return {"skipped": "no OOD classes configured"}

    mu, spread = predict_class_params(model, dataset.n_classes, device)
    sigma_norm = np.linalg.norm(spread, axis=1)

    def score(X):
        preds = classify_by_nearest_centroid(X, mu)
        return sigma_norm[preds]

    id_scores = score(dataset.X_test)
    ood_scores = score(dataset.X_ood)

    y_true = np.concatenate([np.zeros(len(id_scores)), np.ones(len(ood_scores))])
    y_score = np.concatenate([id_scores, ood_scores])
    auroc = roc_auc_score(y_true, y_score)
    return {
        "auroc": float(auroc),
        "id_scores_mean": float(id_scores.mean()),
        "ood_scores_mean": float(ood_scores.mean()),
        "id_scores": id_scores,
        "ood_scores": ood_scores,
    }


# --------------------------------------------------------------------------
# EXPERIMENT 3 & 4: sampling-based metrics for beta sweep and distribution sweep
# --------------------------------------------------------------------------
@torch.no_grad()
def sample_and_evaluate(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    distribution: Distribution,
    k: int = 50,
) -> dict:
    """
    Draw k samples per class, compute:
      - majority-vote accuracy on the test set
      - intra-list diversity (mean pairwise L2 among the k samples per class)
      - spread norm (for diagnostics — if near zero, DESS collapsed to point estimate)
    """
    n_classes = dataset.n_classes
    mu, spread = predict_class_params(model, n_classes, device)

    mu_t = torch.from_numpy(mu).to(device)
    spread_t = torch.from_numpy(spread).to(device)

    # (k, n_classes, D)
    samples = distribution.sample_many(mu_t, spread_t, k=k).cpu().numpy()

    # Classification: for each test point, find nearest sample across (k * n_classes)
    samples_flat = samples.reshape(-1, mu.shape[1])
    labels_rep = np.tile(np.arange(n_classes), k)
    preds = labels_rep[classify_by_nearest_centroid(dataset.X_test, samples_flat)]
    acc = float((preds == dataset.y_test).mean())
    macro_f1 = float(f1_score(dataset.y_test, preds, average="macro"))

    # Intra-list diversity — per class, mean pairwise L2 between the k samples
    ild = []
    for c in range(n_classes):
        sc = samples[:, c, :]                  # (k, D)
        diffs = sc[:, None, :] - sc[None, :, :]
        pw = np.sqrt((diffs ** 2).sum(axis=-1))
        # upper triangle, exclude diagonal
        iu = np.triu_indices(k, k=1)
        ild.append(pw[iu].mean())
    ild_mean = float(np.mean(ild))

    return {
        "accuracy": acc,
        "macro_f1": macro_f1,
        "mean_ild": ild_mean,
        "mean_spread_norm": float(np.linalg.norm(spread, axis=1).mean()),
    }
