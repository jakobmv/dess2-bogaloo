# DESS 20NG Expansion

Codebase for the DESS journal expansion experiments on 20 Newsgroups.
Three Jupyter notebooks progressively build the story — every Python module
below them is a focused building block.

## Layout

```
notebook.ipynb                main orchestrator — Experiments 1–4
notebook_analysis.ipynb       follow-up analyses — A, B, C, E, F
notebook_applications.ipynb   practical applications — G, J, I
notebook_retrieval.ipynb      diversified retrieval demo — R

config.py                     all hyperparameters in one place
data.py                       20NG + AG News loading (with disk cache)
model.py                      DESS MLP + softmax / regression baselines
distributions.py              Gaussian / Laplace / Uniform samplers
losses.py                     single- and multi-target DESS losses
train.py                      training loops
evaluate.py                   metrics per experiment

analysis.py                   follow-up analyses (distance, top-k, calibration, per-dim)
analysis_plots.py             plots paired with analysis.py

applications.py               selective classification, design rule
applications_plots.py         plots paired with applications.py

retrieval.py                  cosine / MMR / random / DESS retrieval + evaluation
retrieval_plots.py            precision/diversity Pareto plot

plots.py                      main-experiment plots
utils.py                      seeding / device / JSON / caching / model save-load
cache/                        SBERT embeddings + trained model checkpoints
results/                      metrics JSON + PNG/PDF figures
```

## Setup

```bash
pip install -r requirements.txt
jupyter lab notebook.ipynb
```

First run will download 20 Newsgroups and embed every document with
`all-MiniLM-L6-v2`. Takes a few minutes on a GPU, cached to disk afterward.

## Experiments

| # | Question                                     | Key metric              |
| - | -------------------------------------------- | ----------------------- |
| 1 | Does DESS work on real data?                 | Accuracy / macro-F1     |
| 2 | Is the predicted σ meaningful?               | Spearman ρ, AUROC       |
| 3 | Does β give controllable diversity?          | Accuracy/diversity Pareto |
| 4 | Do Laplace/Uniform alternatives work?        | Acc + diversity per dist |

Each experiment is one notebook section. You can run them independently;
the smoke-test cell at the top verifies the pipeline before committing
to a full run.

## Notes for Morten

- GPU mapping: container sees cuda:0/1/2 which are host 3/4/5. `utils.get_device`
  picks cuda:0 — adjust if GPU 3 is occupied.
- For long runs, `nohup jupyter nbconvert --to notebook --execute notebook.ipynb` in the
  background rather than keeping the browser open.
- To change hyperparameters, edit `config.py` — everything flows from the `CFG`
  singleton, and `%autoreload` in the notebook picks up changes without restarting.
- Results JSON in `results/` is plain, paper-friendly — easy to copy numbers into
  LaTeX tables.
