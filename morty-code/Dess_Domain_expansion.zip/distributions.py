"""
Per-dimension distributions for DESS inference sampling.

The key insight from the DESS paper is that training is distribution-agnostic:
- mu head is trained with MSE toward the target
- spread head (sigma / b / w) is trained with L1 toward a scaled error target

This means we can swap the *interpretation* of the spread parameter at inference
time without changing training at all. This module defines the three inference
samplers used in Experiment 4.

Each sampler takes (mu, spread) tensors and returns a sampled tensor y_hat.
All operations are vectorized and differentiable (though we don't backprop
through sampling).
"""
from __future__ import annotations

from abc import ABC, abstractmethod

import torch


class Distribution(ABC):
    """Abstract per-dimension sampler."""
    name: str

    @abstractmethod
    def sample(self, mu: torch.Tensor, spread: torch.Tensor) -> torch.Tensor:
        """Draw one sample per element. Input/output shapes match."""
        ...

    def sample_many(
        self,
        mu: torch.Tensor,
        spread: torch.Tensor,
        k: int,
    ) -> torch.Tensor:
        """
        Draw k samples per input. Returns tensor of shape (k, *mu.shape).
        Default implementation loops sample() k times — subclasses can override.
        """
        # Efficient default: broadcast to (k, N, D) by expanding
        mu_k = mu.unsqueeze(0).expand(k, *mu.shape)
        spread_k = spread.unsqueeze(0).expand(k, *spread.shape)
        return self.sample(mu_k, spread_k)


class GaussianDist(Distribution):
    """y_hat_i ~ Normal(mu_i, spread_i^2). The original DESS formulation."""
    name = "gaussian"

    def sample(self, mu, spread):
        eps = torch.randn_like(mu)
        return mu + eps * spread


class LaplaceDist(Distribution):
    """
    y_hat_i ~ Laplace(mu_i, b_i). Heavier tails than Gaussian.

    Note: the DESS L1 loss on the spread parameter is actually the MLE
    for Laplace's scale parameter b, so Laplace is arguably the *natural*
    fit for DESS's training recipe.
    """
    name = "laplace"

    def sample(self, mu, spread):
        # Laplace samples via inverse CDF of a uniform [-0.5, 0.5]:
        #   X = mu - b * sign(u) * log(1 - 2|u|)
        u = torch.rand_like(mu) - 0.5
        return mu - spread * torch.sign(u) * torch.log1p(-2 * torch.abs(u) + 1e-8)


class UniformDist(Distribution):
    """
    y_hat_i ~ Uniform(mu_i - w_i, mu_i + w_i). Bounded exploration.

    The spread parameter is interpreted as half-width. At training time,
    it's still learned via L1 toward beta * |error|, so it naturally tracks
    the scale of error — we just sample flat inside that window at inference.
    """
    name = "uniform"

    def sample(self, mu, spread):
        u = torch.rand_like(mu) * 2 - 1   # uniform in [-1, 1]
        return mu + u * spread


DISTRIBUTIONS: dict[str, Distribution] = {
    "gaussian": GaussianDist(),
    "laplace": LaplaceDist(),
    "uniform": UniformDist(),
}


def get_distribution(name: str) -> Distribution:
    if name not in DISTRIBUTIONS:
        raise ValueError(
            f"Unknown distribution '{name}'. "
            f"Available: {list(DISTRIBUTIONS)}"
        )
    return DISTRIBUTIONS[name]
