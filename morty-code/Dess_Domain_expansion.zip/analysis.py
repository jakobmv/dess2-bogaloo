"""
Follow-up analyses for the DESS 20NG expansion.

Each function takes a trained DESS model + dataset and returns a dict of
results for plotting and logging. These are ADDITIVE — they don't touch
the four main experiments, they just probe the existing model from new angles.

Experiments:
    A — distance histogram           (mechanistic check for β collapse)
    B — fine-grained β sweep         (extend β toward 0 to find the useful regime)
    C — top-k accuracy               (is DESS 'wrong' or just 'dispersed'?)
    E — calibration                  (does σ give probabilistic coverage, not just ranking?)
    F — per-dimension σ structure    (do some dimensions consistently carry more uncertainty?)

Experiments D and G from our discussion are omitted here: D (multi-target dispersion)
requires training new models with modified data, and G (retrofit) requires a new
model architecture. Both are worth doing but belong in their own files.
"""
from __future__ import annotations

import numpy as np
import torch

from data import Dataset20NG
from distributions import Distribution, get_distribution
from evaluate import predict_class_params, classify_by_nearest_centroid


# ==========================================================================
# EXPERIMENT A — sample-distance histogram
# --------------------------------------------------------------------------
# Goal: visualize *why* sampled accuracy collapses at higher β.
# For each β, we have a known ||σ||. The concentration-of-measure prediction
# is that sampled points lie at L2 distance ≈ √d · σ_per_dim from μ. If that
# prediction holds, then as β grows, sampled points drift off the class
# manifold by a predictable amount. This experiment tests that directly.
# ==========================================================================

@torch.no_grad()
def sample_distance_analysis(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    distribution: Distribution,
    n_samples: int = 200,
) -> dict:
    """
    For each class c, sample `n_samples` vectors from the predicted distribution
    and measure the L2 distance between each sample and (a) μ_c itself,
    (b) the nearest other class's μ. This reveals whether samples stay
    near their intended class centroid or cross into neighbors.
    """
    mu, spread = predict_class_params(model, dataset.n_classes, device)
    d = mu.shape[1]

    # theoretical prediction for Gaussian: ||y-mu||_2 ≈ ||σ||_2 (concentration of measure)
    # for d large and σ roughly uniform across dims
    expected_dist = np.linalg.norm(spread, axis=1)    # per class

    mu_t = torch.from_numpy(mu).to(device)
    spread_t = torch.from_numpy(spread).to(device)
    samples = distribution.sample_many(mu_t, spread_t, k=n_samples).cpu().numpy()
    # samples: (n_samples, n_classes, D)

    # For each (sample, class) pair: distance to own mu and to nearest OTHER mu
    dist_to_own = np.zeros((n_samples, dataset.n_classes))
    dist_to_other = np.zeros((n_samples, dataset.n_classes))

    for c in range(dataset.n_classes):
        s = samples[:, c, :]                           # (n_samples, D)
        # distance to own mu
        dist_to_own[:, c] = np.linalg.norm(s - mu[c], axis=1)
        # distance to every other mu, take the min
        diffs = s[:, None, :] - mu[None, :, :]         # (n_samples, n_classes, D)
        all_d = np.linalg.norm(diffs, axis=2)          # (n_samples, n_classes)
        all_d[:, c] = np.inf                           # exclude self
        dist_to_other[:, c] = all_d.min(axis=1)

    # inter-class-mean distance for reference (how far apart are classes, really?)
    mu_pairwise = np.linalg.norm(mu[:, None, :] - mu[None, :, :], axis=2)
    np.fill_diagonal(mu_pairwise, np.nan)
    inter_class_mean = float(np.nanmean(mu_pairwise))
    inter_class_min = float(np.nanmin(mu_pairwise))

    # fraction of samples that are closer to another class than their own
    misplaced = (dist_to_other < dist_to_own).mean()

    return {
        "dist_to_own": dist_to_own,           # (n_samples, n_classes)
        "dist_to_other": dist_to_other,
        "expected_dist": expected_dist,       # (n_classes,) — ||σ|| per class
        "inter_class_mean": inter_class_mean,
        "inter_class_min": inter_class_min,
        "fraction_misplaced": float(misplaced),
        "mean_dist_to_own": float(dist_to_own.mean()),
        "mean_dist_to_other": float(dist_to_other.mean()),
        "d": int(d),
    }


# ==========================================================================
# EXPERIMENT B — fine-grained β sweep toward zero
# --------------------------------------------------------------------------
# Our existing sweep starts at β=0.5 and already shows collapse. Maybe there's
# a regime at β << 0.5 where sampled accuracy approaches point-estimate accuracy.
# If that regime exists, DESS has a useful operating point. If it doesn't,
# that's a cleaner negative result. Either answer is publishable.
# NOTE: this one *does* require retraining at each β — caller should loop.
# ==========================================================================
# (No standalone function here — the notebook loops over β using train_dess.)


# ==========================================================================
# EXPERIMENT C — top-k accuracy at each β
# --------------------------------------------------------------------------
# Goal: distinguish between "DESS samples into wrong class" vs
# "DESS samples into a semantically adjacent class." If top-5 accuracy holds
# up while top-1 collapses, the method is doing retrieval-style dispersion
# rather than outright misclassification — a much more favorable framing.
# ==========================================================================

@torch.no_grad()
def topk_accuracy_analysis(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    distribution: Distribution,
    k_samples: int = 50,
    top_ks: tuple = (1, 3, 5, 10),
) -> dict:
    """
    Sample k_samples per class, then for each test embedding, compute the
    top-K predicted classes by vote across the samples. Report top-K accuracy
    for each K in top_ks.
    """
    mu, spread = predict_class_params(model, dataset.n_classes, device)
    n_classes = dataset.n_classes

    mu_t = torch.from_numpy(mu).to(device)
    spread_t = torch.from_numpy(spread).to(device)
    samples = distribution.sample_many(mu_t, spread_t, k=k_samples).cpu().numpy()
    samples_flat = samples.reshape(-1, mu.shape[1])                 # (k * n_classes, D)
    labels_rep = np.tile(np.arange(n_classes), k_samples)

    X_test, y_test = dataset.X_test, dataset.y_test

    # For each test point: count how often each class shows up as the nearest sample
    # Efficient approach: for each test point, get distances to every sample,
    # sort, pull labels of the top samples (by distance), then vote.
    diffs = X_test[:, None, :] - samples_flat[None, :, :]
    all_d = (diffs ** 2).sum(axis=-1)                               # (N_test, k*n_classes)

    results = {}
    max_k = max(top_ks)

    # Rank samples by distance; take top max_k per test point, look up their class
    # labels, count votes, then check whether the true class is in top-K.
    nearest_sample_idx = np.argpartition(all_d, max_k, axis=1)[:, :max_k]

    for K in top_ks:
        nearest_k = nearest_sample_idx[:, :K]
        nearest_k_labels = labels_rep[nearest_k]                    # (N_test, K)
        # Vectorized vote counting: one-hot over class axis, sum across K axis
        eye = np.eye(n_classes, dtype=np.int32)
        votes = eye[nearest_k_labels].sum(axis=1)                   # (N_test, n_classes)
        # top-K classes by vote
        top_classes_by_votes = np.argsort(-votes, axis=1)[:, :K]
        correct = np.any(top_classes_by_votes == y_test[:, None], axis=1)
        results[f"top_{K}"] = float(correct.mean())

    # Point-estimate reference: top-K by nearest μ instead of sampling
    d_mu = ((X_test[:, None, :] - mu[None, :, :]) ** 2).sum(axis=-1)
    mu_sorted = np.argsort(d_mu, axis=1)
    for K in top_ks:
        correct = np.any(mu_sorted[:, :K] == y_test[:, None], axis=1)
        results[f"point_top_{K}"] = float(correct.mean())

    return results


# ==========================================================================
# EXPERIMENT E — calibration of σ
# --------------------------------------------------------------------------
# Spearman ρ = 0.94 tells us σ rank-orders classes correctly, but not whether
# σ is *absolutely* calibrated. If DESS claims σ=0.05 for some dimension of
# a class, do ~68% of test embeddings for that class fall within ±0.05 along
# that dimension? Calibration plot: predicted σ on x-axis, empirical fraction
# within ±σ on y-axis. Well-calibrated means points lie on the 0.68 horizontal
# line (Gaussian) or the appropriate line for whichever distribution you use.
# ==========================================================================

def calibration_analysis(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    distribution_name: str = "gaussian",
    n_bins: int = 10,
) -> dict:
    """
    For each (class, dimension) bin of predicted σ, measure what fraction of
    test points fall within ±σ of μ̂ along that dimension. Under a correctly
    calibrated Gaussian, that fraction should be ~0.683.
    """
    mu, spread = predict_class_params(model, dataset.n_classes, device)

    # expected coverage for each distribution at ±1 spread-unit from μ
    expected_coverage = {
        "gaussian": 0.6827,                     # 68% within ±1σ
        "laplace":  1.0 - np.exp(-1.0),         # ≈ 0.632, Laplace within ±1b
        "uniform":  1.0,                        # fully inside ±w by construction
    }.get(distribution_name, 0.6827)

    # Build per-(class, dim) empirical "within ±σ?" indicator
    # For each test embedding x with class c, for each dimension i:
    #     in_range[i] = |x[i] - μ[c,i]| < σ[c,i]
    X_test = dataset.X_test
    y_test = dataset.y_test

    all_sigma = []     # predicted σ values
    all_in_range = []  # empirical coverage (0 or 1)

    for c in range(dataset.n_classes):
        mask = y_test == c
        if mask.sum() == 0:
            continue
        xs = X_test[mask]                                   # (N_c, D)
        dev = np.abs(xs - mu[c])                            # (N_c, D)
        in_range = (dev < spread[c]).astype(np.float32)    # (N_c, D)

        # flatten — one point per (class, dim, test-embedding) triple
        sigma_vec = np.tile(spread[c], (len(xs), 1)).flatten()
        in_range_vec = in_range.flatten()
        all_sigma.append(sigma_vec)
        all_in_range.append(in_range_vec)

    sigma_flat = np.concatenate(all_sigma)
    in_range_flat = np.concatenate(all_in_range)

    # Bin by predicted σ, compute empirical coverage per bin
    bin_edges = np.quantile(sigma_flat, np.linspace(0, 1, n_bins + 1))
    bin_edges[-1] += 1e-9     # include the maximum value in the last bin
    bin_ids = np.digitize(sigma_flat, bin_edges) - 1
    bin_ids = np.clip(bin_ids, 0, n_bins - 1)

    bin_sigma = []
    bin_coverage = []
    bin_counts = []
    for b in range(n_bins):
        mask = bin_ids == b
        if mask.sum() == 0:
            continue
        bin_sigma.append(float(sigma_flat[mask].mean()))
        bin_coverage.append(float(in_range_flat[mask].mean()))
        bin_counts.append(int(mask.sum()))

    # overall: fraction of (class, dim, test) triples where |x - μ| < σ
    overall_coverage = float(in_range_flat.mean())

    return {
        "bin_sigma": np.array(bin_sigma),
        "bin_coverage": np.array(bin_coverage),
        "bin_counts": np.array(bin_counts),
        "overall_coverage": overall_coverage,
        "expected_coverage": float(expected_coverage),
        "distribution_name": distribution_name,
    }


# ==========================================================================
# EXPERIMENT F — per-dimension σ structure
# --------------------------------------------------------------------------
# Collapsing σ to ||σ|| throws away 383 out of 384 dimensions of information.
# Let's look at the structure:
#   - Are there SBERT dimensions that consistently carry more uncertainty
#     across all classes? (These would be the "task-uninformative" dimensions.)
#   - Are there dimensions where σ varies strongly across classes? (These are
#     the task-relevant ones where different classes have different characteristic
#     spread — exactly the "structured embedding" claim in the paper's discussion.)
# ==========================================================================

def per_dim_sigma_analysis(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
) -> dict:
    """
    Analyze per-dimension σ structure across classes.
    """
    mu, spread = predict_class_params(model, dataset.n_classes, device)
    d = spread.shape[1]

    # per-dimension stats across classes
    sigma_per_dim_mean = spread.mean(axis=0)          # (D,) — mean σ on each dim
    sigma_per_dim_std = spread.std(axis=0)            # (D,) — how much σ varies across classes

    # empirical per-dim std across all training data (ignores class)
    emp_per_dim = dataset.X_train.std(axis=0)          # (D,)

    # sort dimensions by how "structured" they are
    # (high cross-class variance in σ = classes disagree about uncertainty there)
    structure_score = sigma_per_dim_std / (sigma_per_dim_mean + 1e-9)
    top_structured = np.argsort(-structure_score)[:10]
    least_structured = np.argsort(structure_score)[:10]

    return {
        "sigma_matrix": spread,                        # (n_classes, D)
        "sigma_per_dim_mean": sigma_per_dim_mean,
        "sigma_per_dim_std": sigma_per_dim_std,
        "emp_per_dim": emp_per_dim,
        "structure_score": structure_score,
        "top_structured_dims": top_structured.tolist(),
        "least_structured_dims": least_structured.tolist(),
        "d": int(d),
    }
