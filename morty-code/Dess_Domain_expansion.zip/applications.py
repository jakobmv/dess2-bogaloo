"""
Practical applications of DESS motivated by the characterization findings.

G — Selective classification: use σ as a confidence score, abstain on uncertain inputs.
J — Softmax baseline for selective classification: comparison baseline for G.
I — Design rule transfer: predict the useful β regime from embedding geometry
    on a new dataset (AG News), verify the prediction empirically.

Each function returns a plain dict suitable for JSON serialization and
paired with a plot function in applications_plots.py.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score

from data import Dataset20NG
from evaluate import predict_class_params, classify_by_nearest_centroid


# ==========================================================================
# G — Selective classification via σ thresholding
# --------------------------------------------------------------------------
# For each test point:
#   1. Predict class via nearest μ
#   2. Look up ‖σ‖ of the predicted class — this is the confidence score
#   3. Accept the prediction iff ‖σ‖ is below a threshold
# Sweep thresholds across coverage levels [0.1, ..., 1.0] and report
# accuracy on accepted points. Also runs the same thing on OOD data to
# show σ does NOT help catch OOD (reinforcing Finding 2).
# ==========================================================================

@torch.no_grad()
def selective_classification_dess(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    coverage_levels: tuple = (0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1.0),
) -> dict:
    """
    DESS selective classification.

    Returns per-coverage-level: selective accuracy, selective F1, threshold used.
    """
    mu, spread = predict_class_params(model, dataset.n_classes, device)

    # Predict class by nearest μ for each test point
    preds = classify_by_nearest_centroid(dataset.X_test, mu)

    # Confidence score: ‖σ‖ of the *predicted* class (lower = more confident)
    sigma_norm_per_class = np.linalg.norm(spread, axis=1)
    uncertainty = sigma_norm_per_class[preds]
    correct = (preds == dataset.y_test).astype(np.float32)

    results = []
    for cov in coverage_levels:
        # accept the most-confident `cov` fraction (smallest uncertainty)
        n_keep = int(np.ceil(len(uncertainty) * cov))
        threshold = np.partition(uncertainty, n_keep - 1)[n_keep - 1]
        accepted = uncertainty <= threshold
        kept_acc = correct[accepted].mean()
        kept_f1 = f1_score(
            dataset.y_test[accepted], preds[accepted], average="macro", zero_division=0
        )
        results.append({
            "coverage": float(cov),
            "threshold": float(threshold),
            "n_kept": int(accepted.sum()),
            "selective_accuracy": float(kept_acc),
            "selective_f1": float(kept_f1),
        })

    return {
        "method": "dess_sigma_norm",
        "full_accuracy": float(correct.mean()),
        "by_coverage": results,
    }


@torch.no_grad()
def selective_classification_softmax(
    softmax_model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    coverage_levels: tuple = (0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1.0),
) -> dict:
    """
    J — Softmax baseline: confidence = max softmax probability. Higher = more confident.
    """
    softmax_model.eval()
    x = torch.from_numpy(dataset.X_test).float().to(device)
    logits = softmax_model(x)
    probs = F.softmax(logits, dim=-1).cpu().numpy()
    preds = probs.argmax(axis=1)
    confidence = probs.max(axis=1)
    correct = (preds == dataset.y_test).astype(np.float32)

    results = []
    for cov in coverage_levels:
        n_keep = int(np.ceil(len(confidence) * cov))
        # keep the MOST confident — highest max-prob
        threshold = np.partition(-confidence, n_keep - 1)[n_keep - 1]
        accepted = confidence >= -threshold
        kept_acc = correct[accepted].mean()
        kept_f1 = f1_score(
            dataset.y_test[accepted], preds[accepted], average="macro", zero_division=0
        )
        results.append({
            "coverage": float(cov),
            "threshold": float(-threshold),
            "n_kept": int(accepted.sum()),
            "selective_accuracy": float(kept_acc),
            "selective_f1": float(kept_f1),
        })

    return {
        "method": "softmax_max_prob",
        "full_accuracy": float(correct.mean()),
        "by_coverage": results,
    }


@torch.no_grad()
def selective_classification_ood_check(
    model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
) -> dict:
    """
    Sanity-check: does σ-thresholding catch OOD inputs?

    Expected from Finding 2 (σ is aleatoric, not epistemic): NO. OOD points
    will NOT have systematically higher σ than in-distribution points, so
    a threshold that abstains on X% of in-dist will NOT abstain on ~X% of OOD.

    This is the complementary negative result to G's positive result.
    """
    if dataset.X_ood is None:
        return {"skipped": "no OOD data available"}

    mu, spread = predict_class_params(model, dataset.n_classes, device)
    sigma_norm_per_class = np.linalg.norm(spread, axis=1)

    id_preds = classify_by_nearest_centroid(dataset.X_test, mu)
    ood_preds = classify_by_nearest_centroid(dataset.X_ood, mu)
    id_uncert = sigma_norm_per_class[id_preds]
    ood_uncert = sigma_norm_per_class[ood_preds]

    # For each ID-based coverage threshold, what fraction of OOD gets rejected?
    coverage_levels = (0.5, 0.7, 0.9, 0.95)
    rows = []
    for cov in coverage_levels:
        n_keep = int(np.ceil(len(id_uncert) * cov))
        threshold = np.partition(id_uncert, n_keep - 1)[n_keep - 1]
        id_rejected = (id_uncert > threshold).mean()          # should be ~(1 - cov)
        ood_rejected = (ood_uncert > threshold).mean()
        rows.append({
            "id_coverage_target": float(cov),
            "id_rejection_rate": float(id_rejected),
            "ood_rejection_rate": float(ood_rejected),
            "ood_rejection_lift": float(ood_rejected - id_rejected),
        })
    return {
        "id_mean_sigma": float(id_uncert.mean()),
        "ood_mean_sigma": float(ood_uncert.mean()),
        "rows": rows,
    }


# ==========================================================================
# I — Design rule transfer
# --------------------------------------------------------------------------
# Claim from the characterization:
#   "Sampled classification preserves accuracy iff √d · σ_per_dim <
#   min pairwise inter-class distance. Equivalently, the learned ‖σ‖ must
#   be less than the minimum inter-class distance in μ-space."
# Procedure:
#   1. Compute class centroids from training data of a NEW dataset (AG News)
#   2. Measure min inter-class distance — this is the "safe displacement budget"
#   3. Convert to a β prediction: since ‖σ‖ ≈ β · |δ|, and typical |δ| at
#      training time scales with the embedding geometry, the rule gives a
#      β threshold below which sampling should be safe.
#   4. Train DESS at multiple β, verify that sampled accuracy stays within
#      ε of point-estimate accuracy precisely below the predicted threshold.
# ==========================================================================

def compute_embedding_geometry(dataset: Dataset20NG) -> dict:
    """
    Precomputes the geometric quantities used by the design rule,
    BEFORE training DESS — so they can predict the useful β.
    """
    n_classes = dataset.n_classes
    D = dataset.embedding_dim

    centroids = np.stack([
        dataset.X_train[dataset.y_train == c].mean(axis=0)
        for c in range(n_classes)
    ])

    pairwise = np.linalg.norm(centroids[:, None, :] - centroids[None, :, :], axis=2)
    np.fill_diagonal(pairwise, np.nan)

    inter_class_min = float(np.nanmin(pairwise))
    inter_class_mean = float(np.nanmean(pairwise))

    # per-dim empirical std, averaged across classes — this is what δ's magnitude
    # tracks during single-target training (|δ| ≈ per-dim empirical std, since
    # μ̂ converges to the class mean)
    per_class_std = np.stack([
        dataset.X_train[dataset.y_train == c].std(axis=0)
        for c in range(n_classes)
    ])
    emp_per_dim_std_mean = float(per_class_std.mean())

    # Predicted ||σ|| for a given β:
    #   ‖σ‖ ≈ β · |δ| in L2 ≈ β · sqrt(d) · emp_per_dim_std_mean
    # The design rule says we want ‖σ‖ < inter_class_min, so:
    #   β_max ≈ inter_class_min / (sqrt(d) · emp_per_dim_std_mean)
    beta_max_predicted = inter_class_min / (np.sqrt(D) * emp_per_dim_std_mean)

    return {
        "n_classes": n_classes,
        "embedding_dim": D,
        "inter_class_min": inter_class_min,
        "inter_class_mean": inter_class_mean,
        "emp_per_dim_std_mean": emp_per_dim_std_mean,
        "beta_max_predicted": float(beta_max_predicted),
    }


def evaluate_design_rule(
    geometry: dict,
    beta_sweep_results: list[dict],
    point_estimate_accuracy: float,
    tolerance: float = 0.05,
) -> dict:
    """
    Given the geometry (prediction) and a β sweep (reality), check whether
    the design rule correctly identifies the safe β regime.

    beta_sweep_results: list of dicts with keys {beta, accuracy, mean_spread_norm}

    The rule says: sampled accuracy should be within `tolerance` of point estimate
    whenever mean_spread_norm < inter_class_min. We check:
      - What fraction of (β, result) pairs obey this?
      - How close is the empirical β threshold to the predicted one?
    """
    inter_class_min = geometry["inter_class_min"]
    predicted_beta = geometry["beta_max_predicted"]

    rows = []
    for r in sorted(beta_sweep_results, key=lambda r: r["beta"]):
        spread_norm = r["mean_spread_norm"]
        acc = r["accuracy"]
        is_safe_by_rule = spread_norm < inter_class_min
        is_safe_empirically = (point_estimate_accuracy - acc) <= tolerance
        rows.append({
            "beta": r["beta"],
            "mean_spread_norm": spread_norm,
            "accuracy": acc,
            "acc_loss_vs_point": float(point_estimate_accuracy - acc),
            "rule_says_safe": is_safe_by_rule,
            "empirically_safe": is_safe_empirically,
            "rule_correct": is_safe_by_rule == is_safe_empirically,
        })

    # Empirical β threshold: largest β where acc_loss <= tolerance
    empirical_beta = None
    for r in reversed(rows):
        if r["empirically_safe"]:
            empirical_beta = r["beta"]
            break

    # Concordance: fraction of βs where rule and reality agree
    concordance = float(np.mean([r["rule_correct"] for r in rows]))

    return {
        "geometry": geometry,
        "predicted_beta_max": float(predicted_beta),
        "empirical_beta_max": empirical_beta,
        "point_estimate_accuracy": float(point_estimate_accuracy),
        "tolerance": float(tolerance),
        "rule_concordance": concordance,
        "rows": rows,
    }
