"""Plot for the retrieval comparison — a precision/diversity Pareto scatter."""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from plots import _save


# Method-level style map — keeps every figure using the same colors/markers
METHOD_STYLE = {
    "cosine":  dict(color="#5577aa", marker="o", label="Cosine (relevance baseline)"),
    "random":  dict(color="#888888", marker="x", label="Random (diversity floor)"),
    "dess":    dict(color="#aa5577", marker="*", label="DESS", ms=14),
    "mmr":     dict(color="#55aa77", marker="s", label="MMR"),
}


def _style_for(method_name: str) -> dict:
    if method_name.startswith("mmr_"):
        return METHOD_STYLE["mmr"]
    if method_name.startswith("dess_"):
        # method name is like "dess_uniform_raw" or "dess_uniform_dedup"
        parts = method_name.split("_")
        variant = parts[-1] if parts[-1] in ("raw", "dedup") else "raw"
        dist_name = "_".join(parts[1:-1]) if variant in ("raw", "dedup") else parts[1]
        base = dict(METHOD_STYLE["dess"])
        if variant == "raw":
            # hollow marker for the raw/problematic variant
            base["marker"] = "*"
            base["label"] = f"DESS ({dist_name}, raw)"
        else:
            base["marker"] = "D"
            base["label"] = f"DESS ({dist_name}, dedup)"
        return base
    return METHOD_STYLE.get(method_name, {"color": "black", "marker": ".", "label": method_name})


def plot_retrieval_pareto(
    result: dict,
    name: str = "expR_retrieval",
):
    """
    Scatter: intra-list diversity (x) vs precision@k (y).
    Each method gets one point, except MMR which draws a curve across λ values.
    """
    fig, ax = plt.subplots(figsize=(7, 5))

    # Gather methods into groups for sensible plotting
    mmr_points = []
    other_methods = []

    for m in result["methods"]:
        if m["name"].startswith("mmr_"):
            mmr_points.append(m)
        else:
            other_methods.append(m)

    # Plot MMR as a connected curve across λ (sorted by increasing λ)
    if mmr_points:
        mmr_points.sort(key=lambda m: float(m["name"].split("_")[1]))
        xs = [m["intra_list_div"] for m in mmr_points]
        ys = [m["precision_at_k"] for m in mmr_points]
        style = METHOD_STYLE["mmr"]
        ax.plot(xs, ys, "-", color=style["color"], lw=1.5, alpha=0.7)
        ax.scatter(xs, ys, color=style["color"], marker=style["marker"],
                   s=80, label=style["label"], zorder=3)
        # annotate each MMR point with its λ
        for m, x, y in zip(mmr_points, xs, ys):
            lam = m["name"].split("_")[1]
            ax.annotate(f"λ={lam}", (x, y), xytext=(6, 6),
                        textcoords="offset points", fontsize=8, color=style["color"])

    # Plot the single-point methods
    for m in other_methods:
        style = _style_for(m["name"])
        ms = style.pop("ms", 80)
        # edgecolor only applies to filled markers; 'x' and '+' are unfilled
        filled = style["marker"] not in ("x", "+", "1", "2", "3", "4", "|", "_")
        scatter_kwargs = dict(color=style["color"], marker=style["marker"], s=ms,
                              label=style["label"], zorder=4)
        if filled:
            scatter_kwargs.update(edgecolor="black", linewidth=0.5)
        ax.scatter(m["intra_list_div"], m["precision_at_k"], **scatter_kwargs)

    ax.set_xlabel("Intra-list diversity")
    ax.set_ylabel(f"Precision@{result['k']} (same-class fraction)")
    ax.set_title(
        f"Retrieval precision vs diversity on 20NG  "
        f"(k={result['k']}, {result['n_queries']} queries)"
    )
    ax.legend(loc="best", fontsize=9)
    _save(fig, name)
    plt.close(fig)


def plot_retrieval_bars(result: dict, name: str = "expR_retrieval_bars"):
    """Side-by-side bars — easier to read exact numbers than the scatter."""
    methods = result["methods"]
    names = [m["name"] for m in methods]
    precs = [m["precision_at_k"] for m in methods]
    ilds = [m["intra_list_div"] for m in methods]

    x = np.arange(len(names))
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].bar(x, precs, color="#5577aa")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(names, rotation=30, ha="right")
    axes[0].set_ylabel(f"Precision@{result['k']}")
    axes[0].set_title("Precision by method")
    axes[0].set_ylim(0, 1)

    axes[1].bar(x, ilds, color="#aa5577")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(names, rotation=30, ha="right")
    axes[1].set_ylabel("Intra-list diversity")
    axes[1].set_title("Diversity by method")

    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)
