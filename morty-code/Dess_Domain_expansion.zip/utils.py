"""Small utilities: seeding, device, JSON-safe dumping, caching helpers."""
from __future__ import annotations

import json
import pickle
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch


def set_seed(seed: int) -> None:
    """Seed everything we care about for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device() -> torch.device:
    """
    Pick a GPU if one is available. Morten's setup maps GPUs 3-4-5 to the
    Docker container; torch sees them as cuda:0, cuda:1, cuda:2.
    """
    if torch.cuda.is_available():
        return torch.device("cuda:0")
    return torch.device("cpu")


def save_json(obj: Any, path: Path) -> None:
    """Dump to JSON, converting numpy / torch types to plain Python."""
    def default(o):
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, torch.Tensor):
            return o.detach().cpu().tolist()
        raise TypeError(f"Cannot serialize {type(o)}")

    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=default)


def load_json(path: Path) -> Any:
    with open(path) as f:
        return json.load(f)


def cache_pickle(path: Path, build_fn):
    """
    If `path` exists, unpickle and return it. Otherwise call build_fn(),
    pickle the result, return it. Simple disk-backed memoization.
    """
    path = Path(path)
    if path.exists():
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = build_fn()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(obj, f)
    return obj


def save_model(model: torch.nn.Module, path: Path) -> None:
    """Save a trained model's state_dict to disk."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), path)


def load_model(model: torch.nn.Module, path: Path, device: torch.device) -> torch.nn.Module:
    """Load a state_dict into an already-constructed model. Returns the model (moved to device)."""
    state = torch.load(path, map_location=device)
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    return model
