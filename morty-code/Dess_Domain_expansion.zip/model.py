"""
Models used across the experiments.

- DESSModel : MLP with split mu / sigma heads (the paper's architecture).
- RegressionBaseline : same architecture but only a mu head (ablation for Exp 1).
- SoftmaxBaseline : classic cross-entropy classifier (upper bound for Exp 1).

All three share the same trunk so comparisons are fair.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import ModelConfig


def _make_trunk(in_dim: int, hidden_dims: tuple[int, ...], dropout: float) -> nn.Sequential:
    """Shared MLP body — the last layer is added by each model class separately."""
    layers: list[nn.Module] = []
    prev = in_dim
    for h in hidden_dims:
        layers += [nn.Linear(prev, h), nn.ReLU(), nn.Dropout(dropout)]
        prev = h
    return nn.Sequential(*layers)


class DESSModel(nn.Module):
    """
    DESS predictor.

    Input : one-hot class label (or any feature vector) of size `in_dim`.
    Output: (mu, spread), each of shape (batch, embedding_dim).

    `spread` is constrained positive via softplus so the spread parameter
    is guaranteed > 0 regardless of which distribution interprets it.
    """

    def __init__(
        self,
        in_dim: int,
        embedding_dim: int,
        cfg: ModelConfig,
    ):
        super().__init__()
        self.trunk = _make_trunk(in_dim, cfg.hidden_dims, cfg.dropout)
        last_hidden = cfg.hidden_dims[-1]
        self.mu_head = nn.Linear(last_hidden, embedding_dim)
        self.spread_head = nn.Linear(last_hidden, embedding_dim)
        self.sigma_activation = cfg.sigma_activation

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        h = self.trunk(x)
        mu = self.mu_head(h)
        raw = self.spread_head(h)
        if self.sigma_activation == "softplus":
            spread = F.softplus(raw) + 1e-6   # strictly positive
        elif self.sigma_activation == "exp":
            spread = torch.exp(raw).clamp(min=1e-6, max=10.0)
        else:
            raise ValueError(f"Unknown sigma_activation: {self.sigma_activation}")
        return mu, spread


class RegressionBaseline(nn.Module):
    """DESS minus the sigma head — exactly what Section 5 says DESS generalizes."""

    def __init__(self, in_dim: int, embedding_dim: int, cfg: ModelConfig):
        super().__init__()
        self.trunk = _make_trunk(in_dim, cfg.hidden_dims, cfg.dropout)
        self.mu_head = nn.Linear(cfg.hidden_dims[-1], embedding_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.mu_head(self.trunk(x))


class SoftmaxBaseline(nn.Module):
    """Standard classifier for the fairness-of-comparison upper bound."""

    def __init__(self, in_dim: int, n_classes: int, cfg: ModelConfig):
        super().__init__()
        self.trunk = _make_trunk(in_dim, cfg.hidden_dims, cfg.dropout)
        self.out = nn.Linear(cfg.hidden_dims[-1], n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.out(self.trunk(x))


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
