"""
Retrieval experiment: DESS as a diversity-controlled retrieval method.

Task: for each test document (query), return top-k documents from the training
set that are "related" to it. Compare four methods:

    1. cosine          — top-k by cosine similarity (standard baseline)
    2. mmr             — Maximum Marginal Relevance, λ controls diversity vs relevance
    3. random          — k random documents (diversity floor)
    4. dess_classify   — classify query by nearest μ, sample k points from DESS
                         predicted distribution for that class, retrieve nearest
                         train doc for each sample

Shared metrics per query:
    precision@k        — fraction of retrieved docs sharing the query's class label
    intra_list_div     — mean pairwise L2 distance among retrieved docs

Macro-averaged across the test set. For MMR we sweep λ to get a Pareto curve.

Design choice: we use DESS with Uniform sampling (Experiment 4 established
Uniform > Gaussian > Laplace for classification accuracy). We use β=0.25
on 20NG — just below the design rule's safety threshold — to maximize
diversity while staying in the characterized safe zone. This is the paper's
prescriptive rule applied concretely.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
import torch

from data import Dataset20NG
from distributions import Distribution, get_distribution
from evaluate import predict_class_params, classify_by_nearest_centroid


# ==========================================================================
# Shared utilities
# ==========================================================================

def _l2_normalize(X: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(X, axis=1, keepdims=True)
    return X / np.clip(n, 1e-9, None)


def _intra_list_diversity(indices: np.ndarray, corpus: np.ndarray) -> float:
    """Mean pairwise L2 distance among k retrieved vectors (the 'ILD' metric)."""
    docs = corpus[indices]                     # (k, D)
    diffs = docs[:, None, :] - docs[None, :, :]
    pw = np.sqrt((diffs ** 2).sum(axis=-1))
    iu = np.triu_indices(len(indices), k=1)
    return float(pw[iu].mean())


# ==========================================================================
# Retrieval methods — each returns an (N_queries, k) array of corpus indices
# ==========================================================================

def retrieve_cosine(
    queries: np.ndarray,         # (N_queries, D)
    corpus: np.ndarray,          # (N_corpus, D)
    k: int,
) -> np.ndarray:
    """Top-k by cosine similarity. Assumes both are roughly unit-norm (true for SBERT+normalized)."""
    q = _l2_normalize(queries)
    c = _l2_normalize(corpus)
    sims = q @ c.T                             # (N_queries, N_corpus)
    # argpartition is O(n), then sort the top-k segment for stability
    top = np.argpartition(-sims, k, axis=1)[:, :k]
    # sort within the top-k by similarity descending
    top_sims = np.take_along_axis(sims, top, axis=1)
    order = np.argsort(-top_sims, axis=1)
    return np.take_along_axis(top, order, axis=1)


def retrieve_random(
    queries: np.ndarray,
    corpus: np.ndarray,
    k: int,
    seed: int = 0,
) -> np.ndarray:
    """Random retrieval — diversity floor. Ignores query entirely."""
    rng = np.random.RandomState(seed)
    n = len(corpus)
    out = np.zeros((len(queries), k), dtype=np.int64)
    for i in range(len(queries)):
        out[i] = rng.choice(n, size=k, replace=False)
    return out


def retrieve_mmr(
    queries: np.ndarray,
    corpus: np.ndarray,
    k: int,
    lambda_rel: float = 0.5,
    candidate_pool: int = 100,
) -> np.ndarray:
    """
    Maximum Marginal Relevance retrieval.

    For each query, greedily select k documents that balance:
        score(d) = λ · sim(q, d) − (1−λ) · max_{d' ∈ selected} sim(d, d')

    λ=1 reduces to cosine. λ=0 pursues pure intra-list diversity without
    regard to query relevance. Intermediate values trace the Pareto frontier.

    For tractability we only consider the top `candidate_pool` cosine neighbors
    as candidates — this is the standard MMR shortcut.
    """
    q = _l2_normalize(queries)
    c = _l2_normalize(corpus)
    query_corpus_sim = q @ c.T                          # (N_q, N_c)
    # doc-doc similarity is large so we compute it lazily per query using the pool

    out = np.zeros((len(queries), k), dtype=np.int64)
    for i in range(len(queries)):
        qc = query_corpus_sim[i]
        # take top candidate_pool by similarity as the shortlist
        pool_idx = np.argpartition(-qc, candidate_pool)[:candidate_pool]
        pool_docs = c[pool_idx]                         # (pool, D)
        pool_q_sim = qc[pool_idx]                       # (pool,)
        pool_pairwise = pool_docs @ pool_docs.T         # (pool, pool)

        selected_in_pool: list[int] = []
        available = list(range(candidate_pool))
        for _ in range(k):
            if not available:
                break
            if not selected_in_pool:
                scores = pool_q_sim[available]
            else:
                max_sim_to_selected = pool_pairwise[np.ix_(available, selected_in_pool)].max(axis=1)
                scores = (
                    lambda_rel * pool_q_sim[available]
                    - (1 - lambda_rel) * max_sim_to_selected
                )
            choice_idx_in_available = int(np.argmax(scores))
            chosen = available.pop(choice_idx_in_available)
            selected_in_pool.append(chosen)

        out[i] = pool_idx[selected_in_pool]
    return out


@torch.no_grad()
def retrieve_dess(
    queries: np.ndarray,              # (N_queries, D)
    corpus: np.ndarray,                # (N_corpus, D)
    dess_model: torch.nn.Module,
    dataset: Dataset20NG,              # for n_classes + class-centroid classification
    device: torch.device,
    distribution: Distribution,
    k: int,
    dedupe: bool = False,
    oversample_factor: int = 5,
) -> tuple[np.ndarray, dict]:
    """
    DESS retrieval (Option A — classify-then-sample):
      1. Classify each query by nearest class μ (using trained DESS μ̂ per class).
      2. Sample k (or k × oversample_factor if `dedupe`) vectors from the predicted
         per-dimension distribution for that class.
      3. For each sample, return the nearest corpus doc.
      4. If `dedupe`: return the first k *distinct* corpus indices in order of
         appearance. If fewer than k distinct docs are found, pad with the last
         distinct doc (and record this in diagnostics).

    Returns:
      indices : (N_queries, k) corpus indices
      diag    : dict with diagnostics — mean distinct docs per query, fraction
                of queries that failed to reach k distinct even after oversampling
    """
    mu, spread = predict_class_params(dess_model, dataset.n_classes, device)
    query_classes = classify_by_nearest_centroid(queries, mu)

    mu_t = torch.from_numpy(mu).to(device)
    spread_t = torch.from_numpy(spread).to(device)

    n_samples = k * oversample_factor if dedupe else k

    out = np.zeros((len(queries), k), dtype=np.int64)
    distinct_counts = np.zeros(len(queries), dtype=np.int32)
    pad_short = 0

    for i in range(len(queries)):
        c = int(query_classes[i])
        mu_c = mu_t[c:c+1]
        sp_c = spread_t[c:c+1]
        samples = distribution.sample_many(mu_c, sp_c, k=n_samples).squeeze(1).cpu().numpy()

        diffs = samples[:, None, :] - corpus[None, :, :]
        d2 = (diffs ** 2).sum(axis=-1)
        nearest = d2.argmin(axis=1)                                    # (n_samples,)

        if dedupe:
            seen, ordered_distinct = set(), []
            for idx in nearest:
                if idx not in seen:
                    seen.add(idx)
                    ordered_distinct.append(int(idx))
                    if len(ordered_distinct) == k:
                        break
            distinct_counts[i] = len(ordered_distinct)
            if len(ordered_distinct) < k:
                # corpus is too sparse near μ_c even with oversampling
                pad_short += 1
                ordered_distinct += [ordered_distinct[-1]] * (k - len(ordered_distinct))
            out[i] = ordered_distinct
        else:
            distinct_counts[i] = len(np.unique(nearest[:k]))
            out[i] = nearest[:k]

    diag = {
        "mean_distinct_docs": float(distinct_counts.mean()),
        "min_distinct_docs": int(distinct_counts.min()),
        "fraction_queries_padded": pad_short / len(queries) if dedupe else None,
        "oversample_factor": oversample_factor if dedupe else 1,
    }
    return out, diag


# ==========================================================================
# Evaluation
# ==========================================================================

@dataclass
class RetrievalMetrics:
    method: str
    precision_at_k: float
    intra_list_div: float
    duplicate_rate: float              # fraction of retrievals with any repeated doc


def evaluate_retrieval(
    method_name: str,
    retrieved: np.ndarray,             # (N_queries, k)
    query_labels: np.ndarray,          # (N_queries,)
    corpus_labels: np.ndarray,         # (N_corpus,)
    corpus: np.ndarray,                # (N_corpus, D) for diversity metric
) -> RetrievalMetrics:
    """Compute precision@k and intra-list diversity, macro-averaged across queries."""
    N, k = retrieved.shape
    retrieved_labels = corpus_labels[retrieved]        # (N, k)
    is_same_class = (retrieved_labels == query_labels[:, None])
    precision = float(is_same_class.mean())

    ilds = np.array([_intra_list_diversity(retrieved[i], corpus) for i in range(N)])
    ild = float(ilds.mean())

    # duplicate rate — DESS in particular can return the same doc multiple times
    dup_rate = float(np.mean([len(set(row)) < k for row in retrieved]))

    return RetrievalMetrics(
        method=method_name,
        precision_at_k=precision,
        intra_list_div=ild,
        duplicate_rate=dup_rate,
    )


# ==========================================================================
# Top-level driver — builds all four methods' retrievals and evaluates
# ==========================================================================

def run_retrieval_comparison(
    dess_model: torch.nn.Module,
    dataset: Dataset20NG,
    device: torch.device,
    k: int = 10,
    mmr_lambdas: tuple = (0.2, 0.5, 0.7, 0.9),
    dess_distribution_name: str = "uniform",
    subsample_queries: Optional[int] = 500,
) -> dict:
    """
    Run all retrieval methods and return a dict of results suitable for JSON
    and for plotting.

    subsample_queries: for speed, only evaluate on this many test queries
        (randomly sampled). Set None to use all.
    """
    rng = np.random.RandomState(42)
    X_test, y_test = dataset.X_test, dataset.y_test
    X_train, y_train = dataset.X_train, dataset.y_train

    if subsample_queries is not None and subsample_queries < len(X_test):
        idx = rng.choice(len(X_test), size=subsample_queries, replace=False)
        queries = X_test[idx]
        query_labels = y_test[idx]
    else:
        queries = X_test
        query_labels = y_test

    print(f"[retrieval] {len(queries)} queries against {len(X_train)} corpus docs, k={k}")

    results: list[RetrievalMetrics] = []

    # 1. Cosine baseline
    print("  cosine...")
    ret = retrieve_cosine(queries, X_train, k)
    results.append(evaluate_retrieval("cosine", ret, query_labels, y_train, X_train))

    # 2. Random floor
    print("  random...")
    ret = retrieve_random(queries, X_train, k, seed=42)
    results.append(evaluate_retrieval("random", ret, query_labels, y_train, X_train))

    # 3. MMR at several λ values (one point per λ)
    for lam in mmr_lambdas:
        print(f"  mmr(λ={lam})...")
        ret = retrieve_mmr(queries, X_train, k, lambda_rel=lam)
        results.append(evaluate_retrieval(f"mmr_{lam}", ret, query_labels, y_train, X_train))

    # 4. DESS — both raw and deduped variants, so the paper can show both
    dist = get_distribution(dess_distribution_name)
    diagnostics: dict = {}

    print(f"  dess_{dess_distribution_name}_raw...")
    ret_raw, diag_raw = retrieve_dess(queries, X_train, dess_model, dataset, device, dist, k,
                                       dedupe=False)
    results.append(evaluate_retrieval(
        f"dess_{dess_distribution_name}_raw", ret_raw, query_labels, y_train, X_train
    ))
    diagnostics[f"dess_{dess_distribution_name}_raw"] = diag_raw

    print(f"  dess_{dess_distribution_name}_dedup...")
    ret_ded, diag_ded = retrieve_dess(queries, X_train, dess_model, dataset, device, dist, k,
                                       dedupe=True, oversample_factor=5)
    results.append(evaluate_retrieval(
        f"dess_{dess_distribution_name}_dedup", ret_ded, query_labels, y_train, X_train
    ))
    diagnostics[f"dess_{dess_distribution_name}_dedup"] = diag_ded

    # package as a JSON-friendly dict
    return {
        "k": k,
        "n_queries": len(queries),
        "methods": [
            {
                "name": r.method,
                "precision_at_k": r.precision_at_k,
                "intra_list_div": r.intra_list_div,
                "duplicate_rate": r.duplicate_rate,
            }
            for r in results
        ],
        "dess_diagnostics": diagnostics,
    }
