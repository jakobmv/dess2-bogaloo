"""Plots for the applications experiments (G, I, J)."""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from plots import _save


# --------------------------------------------------------------------------
# G + J — selective classification risk-coverage curve
# --------------------------------------------------------------------------
def plot_selective_classification(
    dess_result: dict,
    softmax_result: dict | None = None,
    name: str = "expG_selective",
):
    """
    Classic risk-coverage plot:
      x = coverage (fraction of test points we make a prediction on)
      y = selective accuracy on the accepted subset
    Higher curve = better uncertainty signal. Ideal: accuracy climbs as
    coverage drops (we're rejecting the hard examples).
    """
    fig, ax = plt.subplots()

    covs = [r["coverage"] for r in dess_result["by_coverage"]]
    accs = [r["selective_accuracy"] for r in dess_result["by_coverage"]]
    ax.plot(covs, accs, "o-", color="#5577aa", label="DESS (‖σ‖ threshold)")

    if softmax_result is not None:
        covs_s = [r["coverage"] for r in softmax_result["by_coverage"]]
        accs_s = [r["selective_accuracy"] for r in softmax_result["by_coverage"]]
        ax.plot(covs_s, accs_s, "s-", color="#aa5577",
                label="Softmax (max-prob threshold)")
        ax.axhline(softmax_result["full_accuracy"], ls=":", color="#aa5577",
                   lw=1, label=f"Softmax full acc ({softmax_result['full_accuracy']:.2f})")

    ax.axhline(dess_result["full_accuracy"], ls="--", color="#5577aa",
               lw=1, label=f"DESS full acc ({dess_result['full_accuracy']:.2f})")
    ax.set_xlabel("Coverage (fraction predicted on)")
    ax.set_ylabel("Selective accuracy")
    ax.set_title("Selective classification — risk-coverage curve")
    ax.set_xlim(min(covs) - 0.05, 1.05)
    ax.legend(loc="lower left", fontsize=9)
    _save(fig, name)
    plt.close(fig)


def plot_ood_selective_check(result: dict, name: str = "expG_ood_check"):
    """Show that σ-thresholding does NOT disproportionately reject OOD."""
    if "skipped" in result:
        print(f"  [plot] OOD check skipped: {result['skipped']}")
        return

    rows = result["rows"]
    covs = [r["id_coverage_target"] for r in rows]
    id_rej = [r["id_rejection_rate"] for r in rows]
    ood_rej = [r["ood_rejection_rate"] for r in rows]

    x = np.arange(len(covs))
    fig, ax = plt.subplots()
    w = 0.35
    ax.bar(x - w/2, id_rej, w, color="#5577aa", label="ID rejection rate")
    ax.bar(x + w/2, ood_rej, w, color="#aa5577", label="OOD rejection rate")
    ax.set_xticks(x)
    ax.set_xticklabels([f"cov={c}" for c in covs])
    ax.set_ylabel("Rejection rate")
    ax.set_title("Does σ-thresholding catch OOD? (Finding 2 check)")
    ax.legend()
    _save(fig, name)
    plt.close(fig)


# --------------------------------------------------------------------------
# I — design rule transfer
# --------------------------------------------------------------------------
def plot_design_rule(result: dict, name: str = "expI_design_rule"):
    """
    Two-panel plot:
      (left)   accuracy vs β, with predicted β_max as a vertical line
      (right)  learned ‖σ‖ vs β, with inter-class min as a horizontal line
               — these lines should cross at approximately the same β
    """
    rows = result["rows"]
    betas = [r["beta"] for r in rows]
    accs = [r["accuracy"] for r in rows]
    spreads = [r["mean_spread_norm"] for r in rows]

    inter_min = result["geometry"]["inter_class_min"]
    predicted_beta = result["predicted_beta_max"]
    empirical_beta = result["empirical_beta_max"]
    point_acc = result["point_estimate_accuracy"]
    tol = result["tolerance"]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    ax = axes[0]
    ax.plot(betas, accs, "o-", color="#5577aa", label="sampled accuracy")
    ax.axhline(point_acc, ls=":", color="k", lw=1, label=f"point acc = {point_acc:.2f}")
    ax.axhline(point_acc - tol, ls="--", color="gray", lw=1,
               label=f"tolerance band (−{tol})")
    ax.axvline(predicted_beta, ls="--", color="red", lw=1.2,
               label=f"predicted β_max = {predicted_beta:.2f}")
    if empirical_beta is not None:
        ax.axvline(empirical_beta, ls="-", color="green", lw=1.2,
                   label=f"empirical β_max = {empirical_beta:.2f}")
    ax.set_xlabel("β")
    ax.set_ylabel("Sampled accuracy")
    ax.set_title("Sampled accuracy vs β")
    ax.legend(fontsize=8, loc="lower left")

    ax = axes[1]
    ax.plot(betas, spreads, "o-", color="#aa5577", label="learned ‖σ‖")
    ax.axhline(inter_min, ls="--", color="red", lw=1.2,
               label=f"inter-class min = {inter_min:.2f}")
    ax.set_xlabel("β")
    ax.set_ylabel("Mean ‖σ‖")
    ax.set_title("Learned spread vs inter-class distance")
    ax.legend(fontsize=8)

    plt.suptitle(
        f"Design rule: ‖σ‖ < inter-class min → safe sampling  "
        f"(rule concordance: {100*result['rule_concordance']:.0f}%)",
        y=1.02,
    )
    plt.tight_layout()
    _save(fig, name)
    plt.close(fig)
