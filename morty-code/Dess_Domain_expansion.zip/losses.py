"""
DESS loss functions — direct implementation of Section 3.2 of the paper.

Single-target:
    L_mu     = (mu_hat - y)^2
    delta    = |mu_hat - y|
    L_sigma  = | spread_hat - beta * delta |

Multi-target (Y has shape (B, T, D)):
    y_bar    = mean_t Y                           # collapse targets
    L_mu     = (mu_hat - y_bar)^2
    delta    = |mu_hat - y_bar|
    dy       = max_t Y - min_t Y                  # per-dimension spread
    tau      = beta * (alpha * delta + (1 - alpha) * dy)
    L_sigma  = | spread_hat - tau |

All losses are element-wise, then reduced to a scalar via .mean().
"""
from __future__ import annotations

import torch


def single_target_loss(
    mu_hat: torch.Tensor,       # (B, D)
    spread_hat: torch.Tensor,   # (B, D)
    y: torch.Tensor,            # (B, D)
    beta: float,
) -> tuple[torch.Tensor, dict]:
    """Returns (scalar loss, dict of logging components)."""
    L_mu = (mu_hat - y).pow(2)
    delta = (mu_hat.detach() - y).abs()     # detach — spread shouldn't pull mu
    L_sigma = (spread_hat - beta * delta).abs()

    loss_mu = L_mu.mean()
    loss_sigma = L_sigma.mean()
    total = loss_mu + loss_sigma

    return total, {
        "loss_total": total.item(),
        "loss_mu": loss_mu.item(),
        "loss_sigma": loss_sigma.item(),
    }


def multi_target_loss(
    mu_hat: torch.Tensor,       # (B, D)
    spread_hat: torch.Tensor,   # (B, D)
    Y: torch.Tensor,            # (B, T, D)
    beta: float,
    alpha: float = 0.5,
) -> tuple[torch.Tensor, dict]:
    """Multi-target loss, with both per-input-error and target-dispersion signals."""
    y_bar = Y.mean(dim=1)                               # (B, D)
    L_mu = (mu_hat - y_bar).pow(2)

    delta = (mu_hat.detach() - y_bar).abs()             # (B, D)
    dy = Y.max(dim=1).values - Y.min(dim=1).values      # (B, D)
    tau = beta * (alpha * delta + (1.0 - alpha) * dy)
    L_sigma = (spread_hat - tau).abs()

    loss_mu = L_mu.mean()
    loss_sigma = L_sigma.mean()
    total = loss_mu + loss_sigma

    return total, {
        "loss_total": total.item(),
        "loss_mu": loss_mu.item(),
        "loss_sigma": loss_sigma.item(),
        "mean_dispersion": dy.mean().item(),
    }


def regression_loss(mu_hat: torch.Tensor, y: torch.Tensor) -> tuple[torch.Tensor, dict]:
    """Simple MSE — for the regression baseline in Experiment 1."""
    L = (mu_hat - y).pow(2).mean()
    return L, {"loss_total": L.item()}
