"""
Central configuration for DESS 20NG expansion experiments.

Every hyperparameter and path lives here. If you want to change something,
change it here — not scattered across the codebase.
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).parent
CACHE_DIR = PROJECT_ROOT / "cache"       # for cached SBERT embeddings
RESULTS_DIR = PROJECT_ROOT / "results"   # for metrics JSON + figures
FIGURES_DIR = RESULTS_DIR / "figures"

for d in (CACHE_DIR, RESULTS_DIR, FIGURES_DIR):
    d.mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------
@dataclass
class DataConfig:
    # sentence-transformers model. MiniLM is 384d, fast. mpnet is 768d, stronger.
    sbert_model: str = "all-MiniLM-L6-v2"
    embedding_dim: int = 384

    # 20NG preprocessing — remove these to prevent metadata leakage
    remove_metadata: tuple = ("headers", "footers", "quotes")

    # train / val / test split fractions (stratified by class)
    train_frac: float = 0.6
    val_frac: float = 0.2
    test_frac: float = 0.2

    # Classes held out entirely for the OOD experiment (2c).
    # Picked to span different supercategories so "OOD" is genuinely novel.
    ood_classes: tuple = (
        "sci.crypt",
        "rec.sport.hockey",
        "talk.politics.mideast",
        "misc.forsale",
        "alt.atheism",
    )


# --------------------------------------------------------------------------
# Model
# --------------------------------------------------------------------------
@dataclass
class ModelConfig:
    # input is one-hot class label; output is 2*embedding_dim (mu and sigma)
    hidden_dims: tuple = (256, 256)
    dropout: float = 0.1

    # sigma head activation — softplus keeps sigma > 0 smoothly
    sigma_activation: str = "softplus"


# --------------------------------------------------------------------------
# Training
# --------------------------------------------------------------------------
@dataclass
class TrainConfig:
    epochs: int = 100
    batch_size: int = 64
    lr: float = 1e-3
    weight_decay: float = 0.0

    # DESS-specific
    beta: float = 1.5       # from the original paper's optimal finding
    alpha: float = 0.5      # weighting for multi-target loss (delta vs dispersion)

    # number of targets per input in a multi-target batch
    # (we sample this many class-c embeddings per class-c input)
    targets_per_input: int = 16

    seed: int = 42


# --------------------------------------------------------------------------
# Experiment 3 — beta sweep
# --------------------------------------------------------------------------
@dataclass
class BetaSweepConfig:
    beta_values: tuple = (0.5, 1.0, 1.25, 1.5, 1.75, 2.0, 2.5)
    samples_per_input: int = 50   # sample k embeddings at inference for diversity
    n_seeds: int = 3              # average over seeds for robustness


# --------------------------------------------------------------------------
# Experiment 4 — alternative distributions
# --------------------------------------------------------------------------
@dataclass
class DistributionConfig:
    # which distributions to compare
    distributions: tuple = ("gaussian", "laplace", "uniform")
    samples_per_input: int = 50


# --------------------------------------------------------------------------
# Master config
# --------------------------------------------------------------------------
@dataclass
class Config:
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    beta_sweep: BetaSweepConfig = field(default_factory=BetaSweepConfig)
    dist: DistributionConfig = field(default_factory=DistributionConfig)

    # number of random seeds for headline metrics (Experiment 1)
    n_seeds: int = 5


# default singleton — import and use, or override per-experiment
CFG = Config()
