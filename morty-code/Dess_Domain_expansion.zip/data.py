"""
20 Newsgroups + SBERT embeddings.

Loads 20NG, embeds every document with a sentence-transformer,
caches the embeddings to disk so re-runs are cheap. Returns a simple
dict of numpy arrays and class names.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
from sklearn.datasets import fetch_20newsgroups
from sklearn.model_selection import train_test_split

from config import CFG, CACHE_DIR, DataConfig
from utils import cache_pickle


@dataclass
class Dataset20NG:
    """
    Container for the processed dataset.

    Each split contains:
        X_emb : (N, embedding_dim) float32   SBERT embeddings
        y     : (N,)              int64     class indices
    """
    X_train: np.ndarray
    y_train: np.ndarray
    X_val: np.ndarray
    y_val: np.ndarray
    X_test: np.ndarray
    y_test: np.ndarray

    class_names: list[str]
    in_dist_classes: list[int]   # class indices kept for main experiments
    ood_classes: list[int]       # class indices held out for OOD test

    # OOD split — only populated if ood_classes is non-empty
    X_ood: Optional[np.ndarray] = None
    y_ood: Optional[np.ndarray] = None

    @property
    def embedding_dim(self) -> int:
        return self.X_train.shape[1]

    @property
    def n_classes(self) -> int:
        return len(self.in_dist_classes)


def _embed_texts(texts: list[str], model_name: str) -> np.ndarray:
    """Encode texts with sentence-transformers. Batched, uses GPU if available."""
    # Imported lazily — sentence-transformers is heavy and we want cache hits
    # to avoid importing it at all.
    from sentence_transformers import SentenceTransformer
    import torch

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = SentenceTransformer(model_name, device=device)
    embeddings = model.encode(
        texts,
        batch_size=64,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=False,   # keep raw embeddings — DESS samples geometry
    )
    return embeddings.astype(np.float32)


def _build_dataset(cfg: DataConfig) -> Dataset20NG:
    """Heavy build: fetch 20NG + embed + split. Only runs on cache miss."""
    print("[data] fetching 20 newsgroups...")
    bundle = fetch_20newsgroups(
        subset="all",
        remove=cfg.remove_metadata,
        shuffle=True,
        random_state=42,
    )
    texts: list[str] = bundle.data
    labels: np.ndarray = np.asarray(bundle.target, dtype=np.int64)
    class_names: list[str] = list(bundle.target_names)

    # filter out empty docs (happens after header/footer/quote removal)
    keep = [i for i, t in enumerate(texts) if len(t.strip()) > 20]
    texts = [texts[i] for i in keep]
    labels = labels[keep]
    print(f"[data] {len(texts)} documents after filtering")

    print(f"[data] embedding with {cfg.sbert_model}...")
    X = _embed_texts(texts, cfg.sbert_model)

    # split OOD classes off first
    ood_class_ids = [class_names.index(c) for c in cfg.ood_classes if c in class_names]
    in_dist_class_ids = [i for i in range(len(class_names)) if i not in ood_class_ids]

    ood_mask = np.isin(labels, ood_class_ids)
    X_ood, y_ood = X[ood_mask], labels[ood_mask]
    X_id, y_id = X[~ood_mask], labels[~ood_mask]

    # remap in-distribution labels to dense 0..K-1 so downstream code is cleaner
    id_remap = {old: new for new, old in enumerate(in_dist_class_ids)}
    y_id_remapped = np.array([id_remap[y] for y in y_id], dtype=np.int64)

    # train/val/test on in-distribution data, stratified
    test_frac = cfg.test_frac
    val_frac_of_remain = cfg.val_frac / (cfg.train_frac + cfg.val_frac)

    X_tv, X_test, y_tv, y_test = train_test_split(
        X_id, y_id_remapped,
        test_size=test_frac,
        random_state=42,
        stratify=y_id_remapped,
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_tv, y_tv,
        test_size=val_frac_of_remain,
        random_state=42,
        stratify=y_tv,
    )

    print(f"[data] splits — train={len(X_train)} val={len(X_val)} "
          f"test={len(X_test)} ood={len(X_ood)}")
    print(f"[data] in-distribution classes: {len(in_dist_class_ids)}")
    print(f"[data] OOD classes: {[class_names[i] for i in ood_class_ids]}")

    return Dataset20NG(
        X_train=X_train, y_train=y_train,
        X_val=X_val, y_val=y_val,
        X_test=X_test, y_test=y_test,
        class_names=class_names,
        in_dist_classes=in_dist_class_ids,
        ood_classes=ood_class_ids,
        X_ood=X_ood if len(X_ood) else None,
        y_ood=y_ood if len(y_ood) else None,
    )


def load_dataset(cfg: Optional[DataConfig] = None, force_rebuild: bool = False) -> Dataset20NG:
    """Public entry point. Cached on disk keyed by SBERT model name."""
    cfg = cfg or CFG.data
    cache_path = CACHE_DIR / f"20ng_{cfg.sbert_model.replace('/', '_')}.pkl"
    if force_rebuild and cache_path.exists():
        cache_path.unlink()
    return cache_pickle(cache_path, lambda: _build_dataset(cfg))


# --------------------------------------------------------------------------
# AG News — second dataset for the transfer experiment
# --------------------------------------------------------------------------
# We only need a small subset: AG News has 4 classes and is ubiquitous in text
# classification. We fetch it from a stable public CSV (HuggingFace mirror),
# subsample to ~8k docs for speed, and run the same SBERT + split pipeline
# as 20NG.
AG_NEWS_TRAIN_URL = "https://huggingface.co/datasets/ag_news/resolve/refs%2Fconvert%2Fparquet/default/train/0000.parquet"
AG_NEWS_TEST_URL  = "https://huggingface.co/datasets/ag_news/resolve/refs%2Fconvert%2Fparquet/default/test/0000.parquet"


def _build_ag_news(cfg: DataConfig, max_per_class: int = 2000) -> Dataset20NG:
    """Download AG News, subsample, embed with SBERT, return Dataset20NG."""
    import pandas as pd

    print("[data] fetching AG News parquet files...")
    try:
        train_df = pd.read_parquet(AG_NEWS_TRAIN_URL)
        test_df = pd.read_parquet(AG_NEWS_TEST_URL)
    except Exception as e:
        raise RuntimeError(
            f"Could not fetch AG News from HuggingFace: {e}\n"
            "If your network blocks huggingface.co, download the parquet files manually "
            "and place them in cache/ag_news_train.parquet and cache/ag_news_test.parquet."
        )

    class_names = ["World", "Sports", "Business", "Sci/Tech"]

    # subsample per class to keep embedding cost reasonable
    def subsample(df, n):
        parts = []
        for c in range(len(class_names)):
            sub = df[df["label"] == c]
            if len(sub) > n:
                sub = sub.sample(n=n, random_state=42)
            parts.append(sub)
        return pd.concat(parts).reset_index(drop=True)

    train_df = subsample(train_df, max_per_class)
    test_df = subsample(test_df, max_per_class // 4)   # smaller test set

    # combine, then split ourselves so the val slice is stratified and reproducible
    all_df = pd.concat([train_df, test_df]).reset_index(drop=True)
    texts = all_df["text"].tolist()
    labels = all_df["label"].to_numpy(dtype=np.int64)

    # filter empty
    keep = [i for i, t in enumerate(texts) if len(str(t).strip()) > 20]
    texts = [texts[i] for i in keep]
    labels = labels[keep]
    print(f"[data] {len(texts)} AG News documents after filtering")

    print(f"[data] embedding with {cfg.sbert_model}...")
    X = _embed_texts(texts, cfg.sbert_model)

    # standard stratified split — no OOD for AG News
    X_tv, X_test, y_tv, y_test = train_test_split(
        X, labels, test_size=cfg.test_frac, random_state=42, stratify=labels,
    )
    val_frac_of_remain = cfg.val_frac / (cfg.train_frac + cfg.val_frac)
    X_train, X_val, y_train, y_val = train_test_split(
        X_tv, y_tv, test_size=val_frac_of_remain, random_state=42, stratify=y_tv,
    )

    print(f"[data] splits — train={len(X_train)} val={len(X_val)} test={len(X_test)}")

    return Dataset20NG(
        X_train=X_train, y_train=y_train,
        X_val=X_val, y_val=y_val,
        X_test=X_test, y_test=y_test,
        class_names=class_names,
        in_dist_classes=list(range(len(class_names))),
        ood_classes=[],
        X_ood=None, y_ood=None,
    )


def load_ag_news(cfg: Optional[DataConfig] = None, force_rebuild: bool = False) -> Dataset20NG:
    """AG News loader with disk cache, parallel to load_dataset()."""
    cfg = cfg or CFG.data
    cache_path = CACHE_DIR / f"agnews_{cfg.sbert_model.replace('/', '_')}.pkl"
    if force_rebuild and cache_path.exists():
        cache_path.unlink()
    return cache_pickle(cache_path, lambda: _build_ag_news(cfg))
